import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

// Read the Supabase URL and Service Role Key from environment variables
// These are set in your Supabase project settings for Edge Functions.
// IMPORTANT: The key names here MUST match the names you used in the Supabase dashboard.
const PROJECT_SUPABASE_URL = Deno.env.get("PROJECT_URL")!;
const PROJECT_SERVICE_ROLE_KEY = Deno.env.get("SERVICE_ROLE_KEY")!;

if (!PROJECT_SUPABASE_URL) {
  throw new Error("PROJECT_URL environment variable is not set.");
}
if (!PROJECT_SERVICE_ROLE_KEY) {
  throw new Error("SERVICE_ROLE_KEY environment variable is not set.");
}

interface PinLoginRequest {
  pin: string;
}

async function verifyPinAndGetUser(supabaseAdmin: SupabaseClient, pin: string) {
  // In a real scenario, you would hash the incoming PIN using the same algorithm
  // used when storing the PIN hash. For simplicity, this example assumes the PIN
  // is already hashed on the client or you are comparing plaintext PINs (NOT RECOMMENDED FOR PRODUCTION).
  // For production, hash the input PIN here before querying.
  // Example: const hashedPin = await bcrypt.hash(pin, 10); (using a library like bcrypt)

  // For this example, let's assume pin_hash in the database is the plaintext pin for simplicity of the example.
  // THIS IS NOT SECURE. YOU MUST HASH PINS.
  const { data: manager, error } = await supabaseAdmin
    .from("gym_managers")
    .select("user_id, gym_id, gyms ( id, name )") // Ensure gym_id and gyms (name) are selected
    .eq("pin_hash", pin) // IMPORTANT: This should be .eq("pin_hash", hashedPinFromInput)
    .eq("is_active", true)
    .single();

  if (error) {
    console.error("Error fetching manager by PIN:", error);
    if (error.code === "PGRST116") { // No rows found
        return { user: null, error: { message: "Invalid PIN or inactive manager.", status: 401 } };
    }
    return { user: null, error: { message: "Database error verifying PIN.", status: 500 } };
  }
  return { user: manager, error: null };
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { pin } = (await req.json()) as PinLoginRequest;

    if (!pin) {
      return new Response(JSON.stringify({ error: "PIN is required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    const supabaseAdmin = createClient(PROJECT_SUPABASE_URL, PROJECT_SERVICE_ROLE_KEY, {
        auth: { persistSession: false } // Important for server-side operations
    });

    const { user: managerInfo, error: pinError } = await verifyPinAndGetUser(supabaseAdmin, pin);

    if (pinError || !managerInfo) {
      return new Response(JSON.stringify({ error: pinError?.message || "Invalid PIN" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: pinError?.status || 401,
      });
    }

    // @ts-ignore: user_id is part of managerInfo
    const managerUserId = managerInfo.user_id;
    // @ts-ignore: gym_id is part of managerInfo
    const managerGymId = managerInfo.gym_id;
    // @ts-ignore: gyms is part of managerInfo, gyms.name is the gym name
    const managerGymName = managerInfo.gyms?.name;

    // If PIN is valid, generate a session for the user_id associated with the PIN
    const { data: sessionData, error: sessionError } = await supabaseAdmin.auth.admin.generateLink({
        type: "magiclink",
        email: `${managerUserId}@example.com`, // Placeholder email, actual email not needed for this session generation method if user exists.
    });

    if (sessionError || !sessionData || !sessionData.properties?.access_token ) {
      console.error("Error generating session for manager:", sessionError);
      return new Response(JSON.stringify({ error: "Could not create session for manager." }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      });
    }
    
    const { data: { user: supabaseUser }, error: userError } = await supabaseAdmin.auth.admin.getUserById(managerUserId);

    if(userError || !supabaseUser) {
        console.error("Error fetching user details for session:", userError);
        return new Response(JSON.stringify({ error: "Could not fetch user details for session." }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 500,
        });
    }

    const session = {
        access_token: sessionData.properties.access_token,
        refresh_token: sessionData.properties.refresh_token,
        user: supabaseUser,
        token_type: "bearer",
        expires_in: sessionData.properties.expires_in,
        expires_at: sessionData.properties.expires_at,
    };

    return new Response(JSON.stringify({ 
        user: supabaseUser, 
        session: session,
        gym_id: managerGymId,      // Include gym_id in the response
        gym_name: managerGymName   // Include gym_name in the response
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error("Unhandled error in PIN login Edge Function:", error);
    return new Response(JSON.stringify({ error: error.message || "Internal server error" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});

/* 
To deploy this Edge Function to your Supabase project:
1. Save this code in your Supabase project under `supabase/functions/login-with-pin/index.ts`.
2. Ensure you have `supabase/_shared/cors.ts`. If not, create it with:
   export const corsHeaders = {
     // IMPORTANT: For production, restrict this to your app's domain e.g. https://yourapp.com
     // Using '*' is insecure for production environments.
     'Access-Control-Allow-Origin': '*', 
     'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
   };
3. Ensure Environment Variables are set in Supabase Dashboard (Project Settings > Edge Functions):
   - PROJECT_URL: Your project's Supabase URL (e.g., https://<your-project-ref>.supabase.co)
   - SERVICE_ROLE_KEY: Your project's service_role key (secret)
4. Deploy the function using the Supabase CLI: `supabase functions deploy login-with-pin --no-verify-jwt`
   (The --no-verify-jwt flag might be needed if the function is invoked by unauthenticated users, which is the case for login).
5. Update your frontend AuthContext.tsx to call this Edge Function: `supabase.functions.invoke('login-with-pin', { body: { pin } })`

SECURITY NOTE ON PINS:
- The provided SQL schema stores `pin_hash` as text. This implies you should be hashing PINs before storing them.
- This Edge Function example currently compares the input PIN directly. THIS IS NOT SECURE.
- You MUST hash the input PIN within this Edge Function using the same hashing algorithm (e.g., bcrypt, Argon2) that you used to create the `pin_hash` in the `gym_managers` table.
*/
