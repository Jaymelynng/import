import React, { useState, useEffect, useCallback } from 'react';
import { MediaCard } from './Card/MediaCard';
import { useAuth } from '../../context/AuthContext'; // Adjusted path
import { supabase } from '../../../lib/supabase'; // Adjusted path
import { MediaItem } from '../../types/media'; // Assuming MediaItem type is defined

// Mocked or to be fetched filters, if MediaFilters component is separate and not passing them down
interface MediaFiltersState {
  searchTerm: string;
  category: string | 'all';
  status: string | 'all';
  // Add other filter types as needed
}

export function MediaGrid() {
  const { user, isAdmin } = useAuth();
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Placeholder for filter state if not managed globally or passed as props
  // For now, we'll fetch all relevant items and assume filtering might be applied visually or by another component
  const [filters, setFilters] = useState<MediaFiltersState>({
    searchTerm: '',
    category: 'all',
    status: 'all',
  });

  const fetchMediaItems = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);

    // Assuming 'marketing_items' table stores media, or a dedicated 'media_assets' table
    // Let's use 'marketing_items' for this example, filtering by types that represent media
    let query = supabase
      .from('marketing_items')
      .select('id, title, description, item_type, created_at, gym_id, asset_url, thumbnail_url, tags, status') // Add relevant fields like asset_url, thumbnail_url, tags
      .in('item_type', ['image', 'video', 'document', 'social_graphic', 'flyer']); // Example media types

    if (user.role === 'manager' && user.gymId) {
      // Managers see their gym's items or global items (gym_id is null)
      query = query.or(`gym_id.eq.${user.gymId},gym_id.is.null`);
    }
    // Admins see all items by default

    // Apply filters (basic example, can be expanded)
    if (filters.searchTerm) {
      query = query.ilike('title', `%${filters.searchTerm}%`);
    }
    if (filters.category !== 'all') {
      // Assuming 'item_type' can be used as category or you have a dedicated category field
      query = query.eq('item_type', filters.category);
    }
    if (filters.status !== 'all') {
        // Assuming 'status' field exists for media items (e.g., 'approved', 'draft')
        query = query.eq('status', filters.status);
    }

    query = query.order('created_at', { ascending: false });

    const { data, error: supaError } = await query;

    if (supaError) {
      console.error('Error fetching media items:', supaError);
      setError(supaError.message);
      setMediaItems([]);
    } else {
      const formattedItems = (data || []).map(item => ({
        id: item.id,
        title: item.title,
        description: item.description,
        type: item.item_type, // Maps to 'category' in MediaCard or a more specific type
        url: item.asset_url, // Main asset URL
        thumbnailUrl: item.thumbnail_url || item.asset_url, // Fallback to asset_url if no thumbnail
        tags: item.tags || [], // Assuming tags is an array field
        gymId: item.gym_id,
        createdAt: item.created_at,
        status: item.status,
        // Add any other necessary transformations
      }));
      setMediaItems(formattedItems as MediaItem[]);
    }
    setLoading(false);
  }, [user, isAdmin, filters]);

  useEffect(() => {
    fetchMediaItems();
  }, [fetchMediaItems]);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 py-8">
        {[...Array(8)].map((_, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden animate-pulse">
            <div className="w-full h-48 bg-gray-300 dark:bg-gray-700"></div>
            <div className="p-4">
              <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-1/2 mb-3"></div>
              <div className="flex flex-wrap gap-2">
                <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-1/4"></div>
                <div className="h-3 bg-gray-300 dark:bg-gray-700 rounded w-1/4"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return <div className="text-center py-12 text-red-500">Error loading media: {error}</div>;
  }

  return (
    <div className="py-8">
      {mediaItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {mediaItems.map((item) => (
            <MediaCard key={item.id} item={item} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-600 dark:text-gray-400 text-lg">No media items found matching your criteria.</p>
          {/* Optionally, suggest changing filters or adding new media */}
        </div>
      )}
    </div>
  );
}

