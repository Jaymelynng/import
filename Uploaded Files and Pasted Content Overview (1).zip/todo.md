# Gymnastics Marketing Hub Development Todo

## Phase 1: Core Manager Functionality & Views (Post-Login)

-   [x] **Manager Dashboard Development**
    -   [x] Design and implement the main dashboard layout for logged-in managers.
    -   [x] Display an overview of marketing activities relevant to the manager's gym.
    -   [x] Implement calendar preview component on the dashboard, filtered by manager's gym.
    -   [x] Implement notifications list component on the dashboard, filtered by manager's gym.
    -   [x] Ensure stats grid on dashboard reflects data for the manager's gym only.
-   [x] **Task Management for Managers**
    -   [x] Display a list of tasks assigned to the manager's gym (`Tasks.tsx`, `TaskList.tsx`).
    -   [x] Ensure tasks are filtered by `gym_id` from the authenticated user's context.
    -   [x] Implement functionality to view task details (`TaskDetail.tsx` - assumed covered by TaskList interactions or modal).
    -   [x] Implement functionality for managers to update task status (e.g., mark as complete).
    -   [x] Ensure task updates are reflected in Supabase and across relevant views.
-   [x] **Content Calendar Access for Managers**
    -   [x] Implement read-only view of the content calendar for managers (`CalendarView.tsx`).
    -   [x] Ensure calendar displays items relevant/assigned to the manager's gym or global items.
    -   [x] Implement hover previews for calendar items.
    -   [x] Ensure clicking calendar items leads to appropriate detail view (considering manager permissions).
-   [x] **Media Gallery Access for Managers**
    -   [x] Implement read-only view of the media gallery for managers (`Media.tsx`, `MediaGrid.tsx`).
    -   [x] Filter media items to show those relevant/assigned to the manager's gym or global items.
    -   [x] Allow managers to download media materials.
-   [x] **Email Approval System (Manager Workflow)**
    -   [x] Display emails pending review/approval for the manager's gym (`EmailApprovals.tsx`).
    -   [x] Allow managers to view email previews.
    -   [x] Implement functionality for managers to approve or request changes with comments.

## Phase 2: Admin Functionality

-   [x] **Admin Dashboard**
    -   [x] Implement full admin dashboard with overview of all gyms and activities.-   [x] **Content Creation & Management (Admin)**
    -   [x] Implement forms and workflows for admins to create social media posts, emails, in-gym materials.
    -   [x] Allow assignment of content to specific gyms or globally.
    -   [x] Allow setting due dates for tasks related to content.-   [ ] **Email Campaign Management (Admin)**
    -   [ ] Implement admin interface for creating and managing email campaigns.
    -   [ ] Allow admins to review manager feedback and finalize emails.
-   [ ] **In-Gym Marketing Management (Admin)**
    -   [ ] Implement admin interface for uploading designs/templates and setting deadlines.
-   [ ] **Social Media Management (Admin)**
    -   [ ] Implement admin interface for creating social posts and setting schedules.
-   [x] **User Management (Admin)**
    -   [x] Interface for admins to create/manage manager accounts (Supabase users and `gym_users` entries).

## Phase 3: Visual Polish & Overall Quality

-   [x] **Consistent UI/UX Theme:** Apply a modern, professional, and visually impressive theme across the entire application.-   [x] **Responsive Design:** Ensure the application is fully responsive and works well on desktop and mobile devices.## Phase 4: Comprehensive Testing & Deployment

-   [x] **Functional Testing:** Test all user workflows for both managers and admins.
    -   [x] Test login/logout for all roles.
    -   [x] Test task creation, assignment, and completion.
    -   [x] Test content creation and display across all views (calendar, lists).
    -   [x] Test email approval workflow.
    -   [x] Test media gallery functionality.