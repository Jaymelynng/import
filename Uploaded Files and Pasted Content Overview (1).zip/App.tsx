import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MainLayout } from './components/Layout/MainLayout';
import { Dashboard } from './pages/Dashboard';
import { Tasks } from './pages/Tasks';
import { TaskDetail } from './components/Tasks/TaskDetail';
import { EmailApprovals } from './pages/EmailApprovals';
import { EmailAdmin } from './pages/EmailAdmin';
import { Media } from './pages/Media';
import { AdminDashboard } from './pages/AdminDashboard';
import { PrintTasks } from './pages/PrintTasks';
import EmailApprovalHub from './pages/EmailApprovalHub';
import GalleryView from './pages/GalleryView';
import CalendarView from './pages/CalendarView';
import LoginPage from './pages/LoginPage'; // Import the LoginPage

// ProtectedRoute component
const ProtectedRoute = () => {
  const { isAuthenticated, loading, user } = useAuth();

  if (loading) {
    // You can render a loading spinner here if you want
    return <div>Loading application...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  // If authenticated, render the child routes
  // Outlet is used by react-router-dom to render nested routes
  return <Outlet />;
};

// Separate component for routes that require MainLayout
const LayoutRoutes = () => (
  <MainLayout>
    <Outlet />
  </MainLayout>
);

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          
          {/* Routes that require authentication and the MainLayout */}
          <Route element={<ProtectedRoute />}>
            <Route element={<LayoutRoutes />}>
              <Route path="/" element={<Dashboard />} /> {/* Default authenticated route */}
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="tasks" element={<Tasks />} />
              <Route path="tasks/:id" element={<TaskDetail />} />
              <Route path="emails" element={<EmailApprovals />} />
              <Route path="emails/admin" element={<EmailAdmin />} />
              <Route path="emails/approval-hub" element={<EmailApprovalHub />} />
              <Route path="media" element={<Media />} />
              <Route path="media/gallery" element={<GalleryView />} />
              <Route path="calendar" element={<CalendarView />} />
              <Route path="admin" element={<AdminDashboard />} /> {/* Consider if this needs its own layout or specific protection */}
              <Route path="admin-dashboard" element={<AdminDashboard />} />
              <Route path="print-tasks" element={<PrintTasks />} />
            </Route>
          </Route>

          {/* Fallback for any other route - might redirect to login or a 404 page */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;

