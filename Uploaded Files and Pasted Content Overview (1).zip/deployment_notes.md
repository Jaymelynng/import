# Gymnastics Marketing Hub - Deployment Notes

This document provides basic guidance for deploying the Gymnastics Marketing Hub application.

## Prerequisites

1.  **Supabase Project:** You need an active Supabase project. You have already set this up and provided the URL and anon key, which are configured in the project's `.env.local` file.
2.  **Database Schema:** The necessary database tables should be set up in your Supabase project. The `complete_schema.sql` file (provided) contains the main schema. Ensure your `gyms` table is populated with your 10 gym locations and the `gym_users` table is correctly linking authenticated users (managers/admins) to their respective gyms and roles.
3.  **Node.js and npm/yarn:** The frontend project is built with Next.js (React) and requires Node.js and a package manager (npm or yarn) to build and run.

## Backend Setup (Supabase)

*   **Database:** Your Supabase database should be set up using the provided SQL schema. The application relies on tables like `gyms`, `users` (Supabase auth), `gym_users`, `marketing_items`, `tasks`, `marketing_content`, etc.
*   **Authentication:** User authentication (email/password) is handled by Supabase Auth. Ensure you create user accounts for admins and managers in the Supabase dashboard (Authentication > Users) and link them in the `gym_users` table with appropriate `gym_id` and `role`.
*   **Environment Variables (Frontend):** The frontend needs to connect to your Supabase instance. This is configured in the `/home/ubuntu/upload/unzipped_files/project/.env.local` file within the project source code. It should contain:
    ```
    NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
    NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_public_anon_key
    ```
    You have already provided these, and they are in the project code I worked on.

## Frontend Deployment (Next.js Application)

The frontend application is located in the `project` directory.

1.  **Install Dependencies:**
    Navigate to the `project` directory in your terminal and run:
    ```bash
    npm install
    ```
    (or `yarn install` if you prefer yarn)

2.  **Build the Application:**
    Run the build command:
    ```bash
    npm run build
    ```
    This will create an optimized production build in the `.next` folder (for Next.js projects like this one, though the original project structure seems to be Vite-based, which would typically build to a `dist` folder. The `npm run dev` command used earlier suggests a Vite setup, which uses `npm run build` and outputs to `dist`. The project structure provided was a Next.js structure, but the `npm run dev` command from the logs points to Vite. I will assume Vite based on the `npm run dev` command for these notes, as it was used to run the dev server. If it's Next.js, the build output is `.next`.)
    *Correction based on project files: The project uses Vite (as seen in `package.json` and `vite.config.ts`). So the build command is `npm run build` and output is typically `dist`.*

3.  **Deploy to a Hosting Provider:**
    You can deploy the contents of the build output directory (e.g., `dist` for Vite) to any static web hosting provider or a platform that supports Node.js applications if it has server-side rendering (SSR) aspects (though this project is primarily client-side rendered with Supabase as BaaS).

    Popular choices for deploying Vite/React applications:
    *   **Vercel:** Excellent integration with Next.js and also supports Vite. Offers a generous free tier.
    *   **Netlify:** Great for static sites and JAMstack applications. Also has a good free tier.
    *   **AWS Amplify:** Part of Amazon Web Services.
    *   **Google Firebase Hosting:** Another popular option.
    *   **Cloudflare Pages:** Good for performance and has a free tier.

    Most of these platforms can be connected directly to a Git repository (e.g., on GitHub, GitLab) for continuous deployment whenever you push changes.

## Running Locally (for further development or testing)

1.  Ensure Supabase is set up and `.env.local` is configured.
2.  Install dependencies: `npm install`
3.  Run the development server: `npm run dev` (This usually starts the app on `http://localhost:5173` or a similar port).

## Important Considerations

*   **User Roles & Permissions:** The application uses the `role` field in the `gym_users` table to differentiate between managers and admins, controlling access to certain features. Ensure these roles are correctly assigned.
*   **Row Level Security (RLS):** The provided `complete_schema.sql` includes Row Level Security policies for Supabase tables. These are crucial for ensuring users can only access data they are permitted to see (e.g., a manager only sees data for their assigned gym). Review and test these policies thoroughly.
*   **Visual Customization:** You can further customize the visual appearance by modifying the Tailwind CSS utility classes used throughout the components and potentially adjusting the `tailwind.config.js` file.

This guide provides a starting point. Specific deployment steps will vary based on your chosen hosting provider.

