import React from 'react';
import { PageHeader } from '../../components/Layout/PageHeader';
import { UserManagementTable } from '../../components/Admin/UserManagementTable';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export function AdminUserManagement() {
  const { isAdmin } = useAuth();

  if (!isAdmin()) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="space-y-8 p-4 md:p-8">
      <PageHeader 
        title="User Management"
        description="Manage gym manager accounts and their assigned gyms."
      />
      <UserManagementTable />
    </div>
  );
}

