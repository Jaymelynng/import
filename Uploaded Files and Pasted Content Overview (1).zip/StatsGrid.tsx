import React, { useEffect, useState } from 'react';
import { ClipboardList, Mail, Calendar, Image as ImageIcon } from 'lucide-react'; // Renamed Image to ImageIcon to avoid conflict
import { supabase } from '../../../lib/supabase'; // Adjusted path assuming lib is three levels up
import { useAuth } from '../../context/AuthContext'; // Adjusted path
import { addDays, isWithinInterval, startOfDay, endOfDay, startOfWeek, endOfWeek, format } from 'date-fns';

interface StatsGridProps {
  gymId?: string; // Optional gymId for filtering manager stats
}

interface Stat {
  title: string;
  count: string;
  icon: React.ElementType;
  description: string;
  bgColor?: string;
  textColor?: string;
}

export function StatsGrid({ gymId }: StatsGridProps) {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      if (!user && !gymId) { // Ensure user context is loaded or gymId is passed for admin
        // For a public dashboard or if user is not yet loaded, show defaults or loading
        // This case should ideally be handled by auth loading state in parent component
        // For now, if no user and no specific gymId (e.g. admin viewing all), we might show aggregate or nothing
        setLoading(false);
        return;
      }

      setLoading(true);
      const today = new Date();
      const twoDaysFromNow = endOfDay(addDays(today, 2)); // Tasks due by end of day, 2 days from now
      const nextSevenDaysEnd = endOfDay(addDays(today, 7));

      // 1. Tasks Due Soon
      let tasksQuery = supabase
        .from('tasks')
        .select('id', { count: 'exact' })
        .gte('due_date', format(startOfDay(today), "yyyy-MM-dd'T'HH:mm:ssXXX"))
        .lte('due_date', format(twoDaysFromNow, "yyyy-MM-dd'T'HH:mm:ssXXX"))
        .neq('status', 'completed'); // Only count non-completed tasks

      if (gymId) {
        tasksQuery = tasksQuery.eq('gym_id', gymId);
      }
      const { count: upcomingTasksCount, error: tasksError } = await tasksQuery;
      if (tasksError) console.error('Error fetching upcoming tasks:', tasksError);

      // 2. Pending Emails (Placeholder - assuming marketing_items of type 'email' need approval)
      // This requires a more specific status like 'pending_approval'
      let emailsQuery = supabase
        .from('marketing_items')
        .select('id', { count: 'exact' })
        .eq('item_type', 'email') // Assuming 'email' type
        // .eq('status', 'pending_approval'); // Add a status field for this
      // if (gymId) { /* Add gym filtering if emails are gym-specific */ }
      const { count: pendingEmailsCount, error: emailsError } = await emailsQuery; // Using total emails for now
      if (emailsError) console.error('Error fetching pending emails:', emailsError);

      // 3. Scheduled Posts (Placeholder - marketing_items of type 'social_post' scheduled soon)
      // Requires a 'scheduled_date' field
      let postsQuery = supabase
        .from('marketing_items')
        .select('id', { count: 'exact' })
        .eq('item_type', 'social_post') // Assuming 'social_post' type
        // .gte('scheduled_date', format(startOfDay(today), "yyyy-MM-dd'T'HH:mm:ssXXX"))
        // .lte('scheduled_date', format(nextSevenDaysEnd, "yyyy-MM-dd'T'HH:mm:ssXXX"))
        // .eq('status', 'scheduled');
      // if (gymId) { /* Add gym filtering if posts are gym-specific */ }
      const { count: scheduledPostsCount, error: postsError } = await postsQuery; // Using total social posts for now
      if (postsError) console.error('Error fetching scheduled posts:', postsError);

      // 4. Uploaded Media (Placeholder - marketing_items of type 'media' or a dedicated media table)
      let mediaQuery = supabase
        .from('marketing_items') // Or a dedicated 'media_assets' table
        .select('id', { count: 'exact' })
        .in('item_type', ['image', 'video', 'document']); // Example media types
      // if (gymId) { /* Add gym filtering if media is gym-specific */ }
      const { count: uploadedMediaCount, error: mediaError } = await mediaQuery;
      if (mediaError) console.error('Error fetching uploaded media:', mediaError);

      const fetchedStats: Stat[] = [
        {
          title: "Tasks Due Soon",
          count: (upcomingTasksCount || 0).toString(),
          icon: ClipboardList,
          description: "Due in next 2 days",
          bgColor: "#e0e7ff", // Light Indigo
          textColor: "#4f46e5" // Indigo
        },
        {
          title: "Pending Emails",
          count: (pendingEmailsCount || 0).toString(), // Placeholder count
          icon: Mail,
          description: "Awaiting approval",
          bgColor: "#fffbeb", // Light Yellow
          textColor: "#d97706" // Yellow
        },
        {
          title: "Scheduled Content",
          count: (scheduledPostsCount || 0).toString(), // Placeholder count
          icon: Calendar,
          description: "Next 7 days",
          bgColor: "#d1fae5", // Light Green
          textColor: "#059669" // Green
        },
        {
          title: "Uploaded Media",
          count: (uploadedMediaCount || 0).toString(), // Placeholder count
          icon: ImageIcon,
          description: "Total assets",
          bgColor: "#fee2e2", // Light Red
          textColor: "#dc2626" // Red
        }
      ];
      setStats(fetchedStats);
      setLoading(false);
    };

    fetchStats();
  }, [user, gymId]);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {[...Array(4)].map((_, index) => (
          <div key={index} className="p-6 rounded-lg shadow-md bg-gray-200 animate-pulse h-32">
            <div className="h-6 bg-gray-300 rounded w-3/4 mb-2"></div>
            <div className="h-8 bg-gray-300 rounded w-1/4 mb-3"></div>
            <div className="h-4 bg-gray-300 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }
  
  if (stats.length === 0) {
      return <div className="text-center py-4">No stats to display.</div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <div
            key={index}
            className="p-6 rounded-lg shadow-lg dark:shadow-gray-700/50"
            style={{ backgroundColor: stat.bgColor || "#f3f4f6" }} // Fallback bg color
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold flex items-center gap-2" style={{ color: stat.textColor || "#374151" }}>
                <Icon size={24} className="opacity-80" />
                {stat.title}
              </h3>
              <p className="text-3xl font-bold" style={{ color: stat.textColor || "#111827" }}>{stat.count}</p>
            </div>
            <p className="text-sm opacity-70" style={{ color: stat.textColor || "#6b7280" }}>{stat.description}</p>
          </div>
        );
      })}
    </div>
  );
}

