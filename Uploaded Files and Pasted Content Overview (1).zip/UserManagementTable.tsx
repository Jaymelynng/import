import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../../lib/supabase';
import { useAuth } from '../../../context/AuthContext';
import { PlusCircle, Edit3, Trash2, Mail, AlertTriangle } from 'lucide-react';

interface ManagedUser {
  id: string; // Supabase auth user ID
  email: string | undefined;
  full_name: string | undefined;
  role: string | undefined; // from gym_users table
  gym_id: string | undefined; // from gym_users table
  gym_name: string | undefined; // from gyms table
  created_at: string;
  // last_sign_in_at: string | undefined;
  gym_user_entry_id?: string; // id from gym_users table, if exists
}

interface Gym {
  id: string;
  name: string;
}

// Simplified Modal for inviting/editing users
const UserModal = ({
  isOpen,
  onClose,
  onSave,
  userToEdit,
  gyms
}: {
  isOpen: boolean;
  onClose: () => void;
  onSave: (email: string, gymId: string | null, role: string, userIdToUpdate?: string) => Promise<void>;
  userToEdit?: ManagedUser | null;
  gyms: Gym[];
}) => {
  const [email, setEmail] = useState('');
  const [selectedGymId, setSelectedGymId] = useState<string | null>(null);
  const [role, setRole] = useState('manager'); // Default role
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (userToEdit) {
      setEmail(userToEdit.email || '');
      setSelectedGymId(userToEdit.gym_id || null);
      setRole(userToEdit.role || 'manager');
    } else {
      setEmail('');
      setSelectedGymId(null);
      setRole('manager');
    }
    setError(null);
  }, [userToEdit, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      await onSave(email, selectedGymId, role, userToEdit?.id);
      onClose(); // Close modal on success
    } catch (err: any) {
      setError(err.message || 'Failed to save user.');
    }
    setIsLoading(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-xl w-full max-w-md">
        <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-100">
          {userToEdit ? 'Edit User Assignment' : 'Invite New User'}
        </h3>
        {error && <p className="text-red-500 text-sm mb-3">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
            <input 
              type="email" 
              id="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              required 
              disabled={!!userToEdit} // Disable email editing for existing users via this modal
              className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-700 dark:text-gray-200"
            />
            {userToEdit && <p className='text-xs text-gray-500 mt-1'>Email cannot be changed. To change email, delete and re-invite.</p>}
          </div>
          <div>
            <label htmlFor="gym" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Assign to Gym</label>
            <select 
              id="gym" 
              value={selectedGymId || ''} 
              onChange={(e) => setSelectedGymId(e.target.value || null)} 
              className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-700 dark:text-gray-200"
            >
              <option value="">Global (No Specific Gym)</option>
              {gyms.map(gym => (
                <option key={gym.id} value={gym.id}>{gym.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="role" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Role</label>
            <select 
              id="role" 
              value={role} 
              onChange={(e) => setRole(e.target.value)} 
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-700 dark:text-gray-200"
            >
              <option value="manager">Manager</option>
              <option value="admin">Admin</option>
              {/* Add other roles as needed */}
            </select>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} disabled={isLoading} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-md shadow-sm">Cancel</button>
            <button type="submit" disabled={isLoading} className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-sm disabled:opacity-50">
              {isLoading ? 'Saving...' : (userToEdit ? 'Save Changes' : 'Send Invite & Assign')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export function UserManagementTable() {
  const { user, isAdmin } = useAuth();
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [gyms, setGyms] = useState<Gym[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<ManagedUser | null>(null);

  const fetchUsersAndAssignments = useCallback(async () => {
    if (!isAdmin()) return;
    setLoading(true);
    setError(null);
    try {
      // Fetch all users from Supabase Auth
      const { data: authUsersData, error: authUsersError } = await supabase.auth.admin.listUsers();
      if (authUsersError) throw authUsersError;

      // Fetch gym assignments from gym_users table
      const { data: gymUsersData, error: gymUsersError } = await supabase
        .from('gym_users')
        .select('id, user_id, gym_id, role, gyms(id, name)'); // Join with gyms table
      if (gymUsersError) throw gymUsersError;

      const managedUsers: ManagedUser[] = (authUsersData.users || []).map(authUser => {
        const assignment = gymUsersData?.find(gu => gu.user_id === authUser.id);
        return {
          id: authUser.id,
          email: authUser.email,
          full_name: authUser.user_metadata?.full_name || authUser.email?.split('@')[0] || 'N/A',
          role: assignment?.role,
          gym_id: assignment?.gym_id,
          // @ts-ignore
          gym_name: assignment?.gyms?.name,
          created_at: new Date(authUser.created_at).toLocaleDateString(),
          // last_sign_in_at: authUser.last_sign_in_at ? new Date(authUser.last_sign_in_at).toLocaleString() : 'Never',
          gym_user_entry_id: assignment?.id
        };
      });
      setUsers(managedUsers.sort((a,b) => (a.full_name || '').localeCompare(b.full_name || '')));
    } catch (e: any) {
      console.error('Error fetching users and assignments:', e);
      setError(e.message || 'Failed to load user data.');
    }
    setLoading(false);
  }, [isAdmin]);

  const fetchGyms = useCallback(async () => {
    const { data, error: gymsError } = await supabase.from('gyms').select('id, name').order('name');
    if (gymsError) {
      console.error('Error fetching gyms:', gymsError);
      setError(gymsError.message);
    } else {
      setGyms(data || []);
    }
  }, []);

  useEffect(() => {
    if (isAdmin()) {
      fetchUsersAndAssignments();
      fetchGyms();
    }
  }, [isAdmin, fetchUsersAndAssignments, fetchGyms]);

  const handleInviteOrSaveUser = async (email: string, gymId: string | null, role: string, userIdToUpdate?: string) => {
    if (!isAdmin()) throw new Error('Permission denied.');

    if (userIdToUpdate) { // Editing existing user's assignment
      const existingAssignment = users.find(u => u.id === userIdToUpdate)?.gym_user_entry_id;
      if (existingAssignment) { // Update existing gym_users entry
        const { error: updateError } = await supabase
          .from('gym_users')
          .update({ gym_id: gymId, role })
          .eq('id', existingAssignment);
        if (updateError) throw updateError;
      } else if (gymId || role) { // Create new gym_users entry if none existed but info provided
        const { error: insertError } = await supabase
          .from('gym_users')
          .insert({ user_id: userIdToUpdate, gym_id: gymId, role });
        if (insertError) throw insertError;
      }
    } else { // Inviting new user
      const { data: inviteData, error: inviteError } = await supabase.auth.admin.inviteUserByEmail(email);
      if (inviteError) throw inviteError;
      if (inviteData.user && (gymId || role)) {
        const { error: assignError } = await supabase
          .from('gym_users')
          .insert({ user_id: inviteData.user.id, gym_id: gymId, role });
        if (assignError) {
          // Attempt to delete the invited user if assignment fails to prevent orphaned auth user
          await supabase.auth.admin.deleteUser(inviteData.user.id);
          throw new Error(`User invited, but failed to assign gym/role: ${assignError.message}. Invite has been rolled back.`);
        }
      }
    }
    fetchUsersAndAssignments(); // Refresh list
  };

  const handleDeleteUserAuthAndAssignment = async (userId: string, gymUserEntryId?: string) => {
    if (!isAdmin()) {
      alert('Permission denied.');
      return;
    }
    if (userId === user?.id) {
        alert("You cannot delete your own account.");
        return;
    }
    if (window.confirm('Are you sure you want to permanently delete this user and their assignments? This action cannot be undone.')) {
      try {
        // 1. Delete from gym_users first (if entry exists)
        if (gymUserEntryId) {
            const { error: assignmentError } = await supabase.from('gym_users').delete().eq('id', gymUserEntryId);
            if (assignmentError) throw new Error(`Failed to delete gym assignment: ${assignmentError.message}`);
        }
        
        // 2. Delete from Supabase Auth
        const { error: authError } = await supabase.auth.admin.deleteUser(userId);
        if (authError) throw new Error(`Failed to delete user from authentication: ${authError.message}`);
        
        alert('User deleted successfully.');
        fetchUsersAndAssignments(); // Refresh list
      } catch (e: any) {
        console.error('Error deleting user:', e);
        alert(`Error: ${e.message}`);
      }
    }
  };
  
  const openInviteModal = () => {
    setUserToEdit(null);
    setIsModalOpen(true);
  };

  const openEditModal = (userToEditData: ManagedUser) => {
    setUserToEdit(userToEditData);
    setIsModalOpen(true);
  };

  if (!isAdmin()) {
    return <div className="p-6 text-center text-red-500">Access Denied. User management is for admins only.</div>;
  }

  if (loading) {
    return <div className="p-6 text-center">Loading user data...</div>;
  }

  if (error) {
    return <div className="p-6 text-center text-red-500">Error: {error}</div>;
  }

  return (
    <div className="bg-white dark:bg-gray-800 shadow-xl rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-200">Manage Users</h2>
        <button 
          onClick={openInviteModal}
          className="flex items-center bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg shadow-sm transition duration-150 ease-in-out"
        >
          <PlusCircle size={18} className="mr-2" /> Invite New User
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Email</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Assigned Gym</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Role</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Joined</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">{u.full_name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{u.email}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{u.gym_name || <span className='italic text-gray-400'>Global</span>}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300 capitalize">{u.role || <span className='italic text-gray-400'>Not Assigned</span>}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{u.created_at}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  <button onClick={() => openEditModal(u)} className="text-indigo-600 hover:text-indigo-800 dark:hover:text-indigo-400 transition-colors" title="Edit Assignment">
                    <Edit3 size={18} />
                  </button>
                  {u.id !== user?.id && (
                    <button onClick={() => handleDeleteUserAuthAndAssignment(u.id, u.gym_user_entry_id)} className="text-red-600 hover:text-red-800 dark:hover:text-red-400 transition-colors" title="Delete User">
                      <Trash2 size={18} />
                    </button>
                  )}
                  {!u.gym_id && !u.role && (
                     <AlertTriangle size={18} className='inline text-yellow-500 ml-1' title='User has no gym/role assignment.' />
                  )}
                </td>
              </tr>
            ))}
            {users.length === 0 && (
                <tr>
                    <td colSpan={6} className="px-6 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
                        No users found. Invite users to get started.
                    </td>
                </tr>
            )}
          </tbody>
        </table>
      </div>
      <UserModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleInviteOrSaveUser} userToEdit={userToEdit} gyms={gyms} />
    </div>
  );
}

