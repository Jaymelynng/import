import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../../lib/supabase';
import { User as AuthUser, Session, SupabaseClient } from '@supabase/supabase-js';

// Define our app-specific User type
export type UserRole = 'admin' | 'manager'; // Assuming 'admin' role might also exist in gym_users or be determined differently

export interface AppUser {
  id: string; // Supabase user ID
  role: UserRole;
  email?: string | null;
  name?: string; // Could come from user_metadata or a profiles table
  gymId?: string; // For managers, from gym_users table
  gymName?: string; // For managers, from gyms table
}

export interface AuthState {
  user: AppUser | null;
  session: Session | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
}

export interface Gym {
  id: string;
  name: string;
}

export interface GymUserDisplay {
  userId: string; // Supabase auth user ID
  name: string; // User's display name
  email: string; // User's email (needed for login, but not shown in dropdown)
}

interface AuthContextType extends AuthState {
  fetchGyms: () => Promise<Gym[]>;
  fetchUsersForGym: (gymId: string) => Promise<GymUserDisplay[]>;
  loginWithGymUserPassword: (email: string, password: string) => Promise<void>;
  loginAdmin: (email_: string, password_: string) => Promise<void>; // Keep admin login separate for now
  logout: () => Promise<void>;
  isAdmin: () => boolean;
  canManageGym: (gymId: string) => boolean;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  const loadAppDataForUser = async (supabaseUser: AuthUser, client: SupabaseClient, currentSession: Session | null) => {
    setLoading(true);
    setError(null);
    try {
      let appUser: AppUser = {
        id: supabaseUser.id,
        email: supabaseUser.email,
        // @ts-ignore - Supabase User type might not have name directly, check user_metadata
        name: supabaseUser.user_metadata?.full_name || supabaseUser.user_metadata?.name || supabaseUser.email,
        role: 'manager', // Default role, will be refined by gym_users lookup
      };

      // Attempt to fetch manager details from gym_users table
      const { data: gymUserData, error: gymUserError } = await client
        .from('gym_users')
        .select(`
          gym_id,
          role,
          gyms ( id, name )
        `)
        .eq('user_id', supabaseUser.id)
        .single();

      if (gymUserError && gymUserError.code !== 'PGRST116') { // PGRST116: 0 rows, not an error if user is admin
        console.error('Error fetching gym_users data:', gymUserError);
        setError('Failed to load user gym data.');
        // Potentially log out or handle as an unprivileged user
      }

      if (gymUserData) {
        appUser.role = gymUserData.role as UserRole; // Cast role from db to UserRole
        appUser.gymId = gymUserData.gym_id;
        // @ts-ignore - gyms is an object if joined, or array. single() makes it object.
        appUser.gymName = gymUserData.gyms?.name;
      } else {
        // If not in gym_users, determine if admin. 
        // This needs a robust admin detection (e.g., custom claims, separate 'profiles' table with roles).
        // For now, placeholder: check if email matches a pattern or if no gym_user entry, assume admin if no error.
        // THIS IS NOT SECURE FOR PRODUCTION for admin detection.
        // A common approach is to check a custom claim set during login by an Edge Function or a trigger,
        // or query a 'user_roles' or 'profiles' table that explicitly defines admins.
        // If the user is authenticated but not in gym_users, they might be an admin.
        // Let's assume for now an admin is NOT in gym_users and has a specific role set elsewhere or by email.
        // For this app, an admin might be someone who logs in via loginAdmin directly.
        // If they logged in via gym user password, they MUST be in gym_users.
        // If an admin logs in via loginAdmin, their role should be set there.
        console.warn(`User ${supabaseUser.id} authenticated but not found in gym_users. Role: ${appUser.role}`);
        // If appUser.role wasn't set to 'admin' by a specific admin login path, this user is in an undefined state.
        // For safety, if not explicitly admin and not in gym_users, they shouldn't have manager privileges.
        if (appUser.role !== 'admin') {
            appUser.gymId = undefined;
            appUser.gymName = undefined;
            // Consider setting role to a generic 'authenticated_user' or logging out if no valid role found.
        }
      }
      setUser(appUser);
      setSession(currentSession);
    } catch (e: any) {
      console.error('Exception in loadAppDataForUser:', e);
      setError(e.message || 'An unexpected error occurred while loading user data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const getInitialSession = async () => {
      setLoading(true);
      const { data: { session: initialSession }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) {
        console.error('Error getting initial session:', sessionError);
        setError('Failed to get initial session.');
      }
      if (initialSession?.user) {
        await loadAppDataForUser(initialSession.user, supabase, initialSession);
      } else {
        setUser(null);
        setSession(null);
      }
      setLoading(false);
    };

    getInitialSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
      if (_event === 'SIGNED_OUT') {
        setUser(null);
        setSession(null);
        setLoading(false);
      } else if (newSession?.user) {
        await loadAppDataForUser(newSession.user, supabase, newSession);
      } else if (_event !== 'INITIAL_SESSION' && _event !== 'USER_UPDATED') {
        // If no new session and user, but not initial load or simple update, clear user
        setUser(null);
        setSession(null);
        setLoading(false);
      }
    });

    return () => {
      authListener?.unsubscribe();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchGyms = async (): Promise<Gym[]> => {
    setError(null);
    const { data, error: fetchError } = await supabase.from('gyms').select('id, name');
    if (fetchError) {
      console.error('Error fetching gyms:', fetchError);
      setError('Failed to fetch gyms.');
      return [];
    }
    return data || [];
  };

  const fetchUsersForGym = async (gymId: string): Promise<GymUserDisplay[]> => {
    setError(null);
    const { data, error: fetchError } = await supabase
      .from('gym_users')
      .select(`
        user_id,
        users ( email, user_metadata->>full_name, user_metadata->>name )
      `)
      .eq('gym_id', gymId);

    if (fetchError) {
      console.error('Error fetching users for gym:', fetchError);
      setError('Failed to fetch users for the selected gym.');
      return [];
    }
    // @ts-ignore map data to GymUserDisplay
    return (data || []).map(gu => ({
      // @ts-ignore
      userId: gu.user_id,
      // @ts-ignore
      name: gu.users?.full_name || gu.users?.name || gu.users?.email || 'Unnamed User',
      // @ts-ignore
      email: gu.users?.email,
    }));
  };

  const loginWithGymUserPassword = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({ email, password });
    if (loginError) {
      console.error('Login error:', loginError);
      setError(loginError.message);
      setLoading(false);
      throw loginError;
    }
    if (loginData.user && loginData.session) {
      // onAuthStateChange will trigger loadAppDataForUser
    } else {
        setError('Login failed: No user or session data returned.');
        setLoading(false);
        throw new Error('Login failed: No user or session data returned.');
    }
    // setLoading(false) will be handled by onAuthStateChange or loadAppDataForUser
  };
  
  const loginAdmin = async (email_: string, password_: string) => {
    setLoading(true);
    setError(null);
    const { data: adminLoginData, error: adminLoginError } = await supabase.auth.signInWithPassword({ email: email_, password: password_ });
    if (adminLoginError) {
      console.error('Admin login error:', adminLoginError);
      setError(adminLoginError.message);
      setLoading(false);
      throw adminLoginError;
    }
    if (adminLoginData.user && adminLoginData.session) {
      // Manually set admin role here if not using gym_users for admins
      // This is a simplified admin check. Production systems need robust role management.
      const adminAppUser: AppUser = {
        id: adminLoginData.user.id,
        email: adminLoginData.user.email,
        // @ts-ignore
        name: adminLoginData.user.user_metadata?.full_name || adminLoginData.user.email,
        role: 'admin',
      };
      setUser(adminAppUser);
      setSession(adminLoginData.session);
      setLoading(false);
    } else {
        setError('Admin login failed: No user or session data returned.');
        setLoading(false);
        throw new Error('Admin login failed: No user or session data returned.');
    }
  };

  const logout = async () => {
    setLoading(true);
    setError(null);
    const { error: signOutError } = await supabase.auth.signOut();
    if (signOutError) {
        console.error('Error signing out:', signOutError);
        setError('Failed to sign out.');
    }
    // onAuthStateChange will handle setting user and session to null
    // setLoading(false) will be handled by onAuthStateChange
  };

  const isAdmin = () => {
    return user?.role === 'admin';
  };

  const canManageGym = (gymIdToCheck: string) => {
    if (!user) return false;
    if (user.role === 'admin') return true; // Admins can manage any gym
    return user.role === 'manager' && user.gymId === gymIdToCheck;
  };

  return (
    <AuthContext.Provider value={{ user, session, isAuthenticated: !!user, loading, error, fetchGyms, fetchUsersForGym, loginWithGymUserPassword, loginAdmin, logout, isAdmin, canManageGym, clearError }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
