import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../../lib/supabase'; // Adjusted path
import { useAuth } from '../../../context/AuthContext'; // Adjusted path
import { MarketingItem } from '../../types/marketing'; // Assuming a general type
import { Task } from '../../types/tasks'; // Assuming a task type
import { format, parseISO } from 'date-fns';

interface CalendarEntry {
  id: string;
  type: 'task' | 'email' | 'social_post' | 'flyer' | 'video_ad' | 'blog_post' | 'in_gym_material' | 'other_marketing_item';
  title: string;
  date: string; // ISO string or formatted date string
  status?: string;
  gymName?: string | null; // Optional: for displaying gym assignment
  item_type?: string; // from marketing_items
}

export function ContentCalendar() {
  const { isAdmin } = useAuth();
  const [allContent, setAllContent] = useState<CalendarEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAllContent = useCallback(async () => {
    if (!isAdmin()) {
      setLoading(false);
      setError('Access Denied. Only admins can view the full content calendar.');
      return;
    }
    setLoading(true);
    setError(null);

    try {
      // Fetch marketing items
      const { data: marketingItemsData, error: marketingItemsError } = await supabase
        .from('marketing_items')
        .select('id, title, item_type, schedule_date, created_at, status, gyms(name)') // Join with gyms table to get gym name
        .order('schedule_date', { ascending: true, nullsLast: true });

      if (marketingItemsError) throw marketingItemsError;

      // Fetch tasks (assuming tasks are also relevant for a content calendar)
      const { data: tasksData, error: tasksError } = await supabase
        .from('tasks')
        .select('id, title, due_date, status, gyms(name)') // Join with gyms table
        .order('due_date', { ascending: true, nullsLast: true });
      
      if (tasksError) throw tasksError;

      const formattedMarketingItems: CalendarEntry[] = (marketingItemsData || []).map((item: any) => ({
        id: item.id,
        // @ts-ignore
        type: item.item_type || 'other_marketing_item',
        title: item.title,
        // @ts-ignore
        date: item.schedule_date || item.created_at, // Prefer schedule_date
        status: item.status,
        // @ts-ignore
        gymName: item.gyms?.name || (item.gym_id ? 'Specific Gym (ID not found)' : 'Global'),
        item_type: item.item_type,
      }));

      const formattedTasks: CalendarEntry[] = (tasksData || []).map((task: any) => ({
        id: task.id,
        type: 'task',
        title: task.title,
        date: task.due_date,
        status: task.status,
        // @ts-ignore
        gymName: task.gyms?.name || (task.gym_id ? 'Specific Gym (ID not found)' : 'Global Task'),
      }));

      const combinedContent = [...formattedMarketingItems, ...formattedTasks]
        .filter(item => item.date) // Ensure items have a date
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
      setAllContent(combinedContent);

    } catch (e: any) {
      console.error('Error fetching content calendar data:', e);
      setError(e.message || 'Failed to load content calendar data.');
      setAllContent([]);
    } finally {
      setLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    fetchAllContent();
  }, [fetchAllContent]);

  if (!isAdmin()) {
    return <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 text-center text-red-500">{error || 'Access Denied.'}</div>;
  }

  if (loading) {
    return <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 text-center">Loading Content Calendar...</div>;
  }

  if (error) {
    return <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 text-center text-red-500">Error: {error}</div>;
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 shadow-lg">
      <h2 className="text-2xl font-semibold mb-6 text-gray-700 dark:text-gray-200">Master Content Calendar</h2>
      
      {allContent.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">No content or tasks scheduled yet.</p>
      ) : (
        <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
          {allContent.map((item) => (
            <div
              key={`${item.type}-${item.id}`}
              className="p-4 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <div className='flex-grow min-w-0'>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full mr-2 capitalize
                    ${item.type === 'task' ? 'bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-blue-100' 
                      : item.type === 'email' ? 'bg-green-100 text-green-700 dark:bg-green-700 dark:text-green-100' 
                      : 'bg-purple-100 text-purple-700 dark:bg-purple-700 dark:text-purple-100'}
                  `}>
                    {item.item_type ? item.item_type.replace('_', ' ') : item.type.replace('_', ' ')}
                  </span>
                  <h3 className="font-medium text-gray-800 dark:text-gray-100 truncate" title={item.title}>{item.title}</h3>
                </div>
                <div className='text-right flex-shrink-0'>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    {format(parseISO(item.date), 'MMM dd, yyyy')}
                  </p>
                  {item.gymName && item.gymName !== 'Global' && (
                     <p className="text-xs text-gray-500 dark:text-gray-400">{item.gymName}</p>
                  )}
                </div>
              </div>
              {item.status && (
                <p className="text-xs mt-1 capitalize text-gray-500 dark:text-gray-400">Status: <span className='font-medium'>{item.status.replace('_', ' ')}</span></p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

