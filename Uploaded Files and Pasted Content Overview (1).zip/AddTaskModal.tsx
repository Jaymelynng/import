import React, { useState, useEffect, FormEvent } from 'react';
import { X, Plus, CheckSquare, Calendar, Clock, Save } from 'lucide-react';
import { supabase } from '../../../lib/supabase'; // Adjusted path
import { useAuth } from '../../context/AuthContext';
import { TASK_CHANNEL_LABELS, TASK_STATUS_LABELS, TaskStatus, TaskChannel, DEFAULT_TASK_STATUS } from '../../utils/constants';
import { Task } from '../../types/tasks';
import { Gym } from '../../context/AuthContext'; // Assuming Gym type is exported from AuthContext

interface AddTaskModalProps {
  onClose: () => void;
  gymIdForManager?: string; // For managers, their gymId is pre-filled and read-only
  taskToEdit?: Task | null;
}

interface FormData {
  title: string;
  description: string;
  due_date: string;
  go_live_date?: string | null;
  status: TaskStatus;
  // channel: TaskChannel; // Channel might be derived from marketing_item_type or a direct field
  priority: 'low' | 'medium' | 'high';
  gym_id?: string | null; // For admins to select, or pre-filled for managers
  marketing_item_id?: string | null; // Link to a marketing item
  // Checklist items will be handled as part of the description for simplicity for now
}

export function AddTaskModal({ onClose, gymIdForManager, taskToEdit }: AddTaskModalProps) {
  const { user, isAdmin } = useAuth();
  const [formData, setFormData] = useState<FormData>({
    title: '',
    description: '',
    due_date: '',
    go_live_date: null,
    status: DEFAULT_TASK_STATUS,
    // channel: 'general',
    priority: 'medium',
    gym_id: gymIdForManager || null,
    marketing_item_id: null,
  });
  const [checklistItems, setChecklistItems] = useState<string[]>(['']);
  const [allGyms, setAllGyms] = useState<Gym[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isAdmin()) {
      const fetchGyms = async () => {
        const { data, error: fetchError } = await supabase.from('gyms').select('id, name');
        if (fetchError) {
          console.error('Error fetching gyms:', fetchError);
        } else {
          setAllGyms(data || []);
        }
      };
      fetchGyms();
    }
  }, [isAdmin]);

  useEffect(() => {
    if (taskToEdit) {
      setFormData({
        title: taskToEdit.title || '',
        description: taskToEdit.description?.split('\n\nChecklist:')[0] || '', // Extract main description
        due_date: taskToEdit.dueDate ? new Date(taskToEdit.dueDate).toISOString().split('T')[0] : '',
        go_live_date: taskToEdit.goLiveDate ? new Date(taskToEdit.goLiveDate).toISOString().split('T')[0] : null,
        status: taskToEdit.status || DEFAULT_TASK_STATUS,
        // channel: taskToEdit.channel || 'general',
        priority: taskToEdit.priority || 'medium',
        gym_id: taskToEdit.gymId || gymIdForManager || null,
        marketing_item_id: taskToEdit.marketing_item_id || null,
      });
      // Extract checklist from description if present
      const checklistRegex = /\n\nChecklist:\n((?:- \[ \] .*\n?)*)/;
      const match = taskToEdit.description?.match(checklistRegex);
      if (match && match[1]) {
        const items = match[1].split('\n').filter(item => item.startsWith('- [ ] ')).map(item => item.substring(6));
        setChecklistItems(items.length > 0 ? items : ['']);
      } else {
        setChecklistItems(['']);
      }
    } else {
      // Reset for new task, ensuring manager's gymId is set if applicable
      setFormData(prev => ({ ...prev, gym_id: gymIdForManager || null }));
    }
  }, [taskToEdit, gymIdForManager]);

  const formatDescriptionWithChecklist = (description: string, items: string[]): string => {
    const cleanedItems = items.filter(item => item.trim() !== '');
    if (cleanedItems.length === 0) {
      return description;
    }
    return `${description}\n\nChecklist:\n${cleanedItems.map(item => `- [ ] ${item}`).join('\n')}`;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!user) {
      setError('You must be logged in to perform this action.');
      setLoading(false);
      return;
    }

    const finalDescription = formatDescriptionWithChecklist(formData.description, checklistItems);
    
    const taskDataToSave = {
      ...formData,
      description: finalDescription,
      // Ensure gym_id is set, especially for managers
      gym_id: isAdmin() ? formData.gym_id : (user.gymId || formData.gym_id), // Manager's gymId takes precedence if not admin
      user_id: user.id, // Track who created/updated the task
      // go_live_date can be null if not provided
      go_live_date: formData.go_live_date || null,
    };

    let response;
    if (taskToEdit && taskToEdit.id) {
      // Update existing task
      response = await supabase
        .from('tasks')
        .update(taskDataToSave)
        .eq('id', taskToEdit.id);
    } else {
      // Create new task
      response = await supabase.from('tasks').insert([taskDataToSave]);
    }

    const { error: supaError } = response;

    if (supaError) {
      console.error('Error saving task:', supaError);
      setError(supaError.message);
    } else {
      onClose(); // Close modal on success
    }
    setLoading(false);
  };

  const addChecklistItemField = () => {
    setChecklistItems(prev => [...prev, '']);
  };

  const updateChecklistItemField = (index: number, value: string) => {
    setChecklistItems(prev => prev.map((item, i) => (i === index ? value : item)));
  };

  const removeChecklistItemField = (index: number) => {
    setChecklistItems(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="flex justify-between items-center mb-6 pb-3 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
            {taskToEdit ? 'Edit Task' : 'Add New Task'}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="title" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Title</label>
            <input
              id="title"
              type="text"
              value={formData.title}
              onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
              className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          {/* Channel selection can be added here if tasks have a direct channel field or if linked to marketing_items with types */}

          <div>
            <label htmlFor="description" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Description</label>
            <textarea
              id="description"
              value={formData.description}
              onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
              className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              rows={3}
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-2">
                <CheckSquare size={16} />
                Checklist Items
              </label>
              <button
                type="button"
                onClick={addChecklistItemField}
                className="text-xs text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 flex items-center gap-1"
              >
                <Plus size={14} />
                Add Item
              </button>
            </div>
            <div className="space-y-2">
              {checklistItems.map((item, index) => (
                <div key={index} className="flex gap-2 items-center">
                  <input
                    type="text"
                    value={item}
                    onChange={e => updateChecklistItemField(index, e.target.value)}
                    className="flex-1 px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder={`Checklist item ${index + 1}`}
                  />
                  {checklistItems.length > 0 && (
                    <button
                      type="button"
                      onClick={() => removeChecklistItemField(index)}
                      className="p-1.5 rounded-md text-red-500 hover:bg-red-100 dark:hover:bg-gray-600"
                      title="Remove item"
                    >
                      <X size={16} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="due_date" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300 flex items-center gap-2">
                <Clock size={16} /> Due Date
              </label>
              <input
                id="due_date"
                type="date"
                value={formData.due_date}
                onChange={e => setFormData(prev => ({ ...prev, due_date: e.target.value }))}
                className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label htmlFor="go_live_date" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300 flex items-center gap-2">
                <Calendar size={16} /> Go Live Date (Optional)
              </label>
              <input
                id="go_live_date"
                type="date"
                value={formData.go_live_date || ''}
                onChange={e => setFormData(prev => ({ ...prev, go_live_date: e.target.value || null }))}
                className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label htmlFor="status" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Status</label>
              <select
                id="status"
                value={formData.status}
                onChange={e => setFormData(prev => ({ ...prev, status: e.target.value as TaskStatus }))}
                className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {Object.entries(TASK_STATUS_LABELS).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="priority" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Priority</label>
              <select
                id="priority"
                value={formData.priority}
                onChange={e => setFormData(prev => ({ ...prev, priority: e.target.value as 'low' | 'medium' | 'high' }))}
                className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
            {isAdmin() && (
              <div className="sm:col-span-2">
                <label htmlFor="gym_id" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Assign to Gym (Admin)</label>
                <select
                  id="gym_id"
                  value={formData.gym_id || ''}
                  onChange={e => setFormData(prev => ({ ...prev, gym_id: e.target.value || null }))}
                  className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  disabled={!isAdmin() || allGyms.length === 0}
                >
                  <option value="">-- Select Gym (Optional) --</option>
                  {allGyms.map(gym => (
                    <option key={gym.id} value={gym.id}>{gym.name}</option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {error && <p className="text-sm text-red-600 dark:text-red-400">Error: {error}</p>}

          <div className="flex justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-md border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 flex items-center gap-2 transition-colors"
              disabled={loading}
            >
              <Save size={16} />
              {loading ? 'Saving...' : (taskToEdit ? 'Save Changes' : 'Create Task')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

