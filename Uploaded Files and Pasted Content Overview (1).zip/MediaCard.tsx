import React, { useState } from 'react';
import { ExternalLink, Edit2, Trash2, Download } from 'lucide-react'; // Added Download icon
import { MediaItem } from '../../../types/media';
// import { useMediaStore } from '../../../store/mediaStore'; // Assuming this will be replaced by Supabase direct calls or context
import { MediaEditModal } from '../Edit/MediaEditModal'; // Assuming this will be updated for Supabase
import { supabase } from '../../../../lib/supabase'; // For delete and potentially edit operations
import { useAuth } from '../../../context/AuthContext';

interface MediaCardProps {
  item: MediaItem;
  onDeleteSuccess?: (itemId: string) => void; // Callback to update parent list
  onEditSuccess?: (updatedItem: MediaItem) => void; // Callback to update parent list
}

export function MediaCard({ item, onDeleteSuccess, onEditSuccess }: MediaCardProps) {
  // const { deleteItem } = useMediaStore(); // Replace with direct Supabase call
  const { isAdmin } = useAuth();
  const [showEditModal, setShowEditModal] = useState(false);

  const handleClick = () => {
    if (item.type === 'link' && item.url) { // Assuming 'link' type and 'url' field for external links
      window.open(item.url, '_blank');
    }
    // For other types, clicking the image might open a larger preview modal in the future
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAdmin()) {
        alert("You don't have permission to delete media items.");
        return;
    }
    if (window.confirm('Are you sure you want to delete this item?')) {
      const { error } = await supabase.from('marketing_items').delete().eq('id', item.id);
      if (error) {
        console.error('Error deleting media item:', error);
        alert(`Failed to delete item: ${error.message}`);
      } else {
        if (onDeleteSuccess) onDeleteSuccess(item.id);
      }
    }
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!item.url) {
      alert('No downloadable asset URL found for this item.');
      return;
    }
    try {
      // For Supabase storage, if URL is a signed URL or public URL, direct download works.
      // If it's a private URL that needs special handling, this might need to fetch blob then download.
      const response = await fetch(item.url);
      if (!response.ok) throw new Error(`Failed to fetch asset: ${response.statusText}`);
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      // Try to get a filename from the URL or use a default
      const filename = item.url.substring(item.url.lastIndexOf('/') + 1) || `download-${item.id}`;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error('Error downloading asset:', error);
      alert(`Failed to download asset: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  return (
    <>
      <div 
        className={`bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-xl transition-all duration-200 ease-in-out flex flex-col h-full ${
          item.type === 'link' ? 'cursor-pointer' : ''
        }`}
      >
        <div className="aspect-video relative group bg-gray-100 dark:bg-gray-700">
          <img
            src={item.thumbnailUrl || '/placeholder-image.svg'} // Fallback placeholder
            alt={item.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            onClick={item.type === 'link' ? handleClick : undefined}
            onError={(e) => (e.currentTarget.src = '/placeholder-image.svg')} // Handle broken image links
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all flex items-center justify-center gap-2 sm:gap-3">
            {item.type !== 'link' && item.url && (
                <button
                    onClick={handleDownload}
                    className="p-2 sm:p-2.5 rounded-full bg-white/80 backdrop-blur-sm text-blue-600 hover:bg-white opacity-0 group-hover:opacity-100 transition-opacity duration-200 transform group-hover:scale-110 hover:scale-125"
                    title="Download"
                >
                    <Download size={18} />
                </button>
            )}
            {isAdmin() && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowEditModal(true);
                  }}
                  className="p-2 sm:p-2.5 rounded-full bg-white/80 backdrop-blur-sm text-gray-700 hover:bg-white opacity-0 group-hover:opacity-100 transition-opacity duration-200 transform group-hover:scale-110 hover:scale-125"
                  title="Edit"
                >
                  <Edit2 size={16} />
                </button>
                <button
                  onClick={handleDelete}
                  className="p-2 sm:p-2.5 rounded-full bg-white/80 backdrop-blur-sm text-red-500 hover:bg-white opacity-0 group-hover:opacity-100 transition-opacity duration-200 transform group-hover:scale-110 hover:scale-125"
                  title="Delete"
                >
                  <Trash2 size={16} />
                </button>
              </>
            )}
          </div>
        </div>
        <div className="p-4 flex-grow flex flex-col justify-between">
          <div>
            <h3 className="font-semibold text-md text-gray-800 dark:text-gray-100 mb-1.5 truncate" title={item.title}>
              {item.title}
              {item.type === 'link' && (
                <ExternalLink className="inline-block ml-1.5 text-gray-400 dark:text-gray-500" size={14} />
              )}
            </h3>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-700 dark:text-indigo-100 capitalize">
                {item.type?.replace('_', ' ') || 'Media'}
              </span>
              {/* Add other relevant badges like status or gym assignment if applicable */}
              {item.status && (
                <span className={`text-xs px-2 py-0.5 rounded-full capitalize ${item.status === 'approved' ? 'bg-green-100 text-green-700 dark:bg-green-700 dark:text-green-100' : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-700 dark:text-yellow-100'}`}>
                    {item.status}
                </span>
              )}
            </div>
            {item.description && (
              <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 mb-2" title={item.description}>{item.description}</p>
            )}
          </div>
          {item.tags && item.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-auto pt-2 border-t border-gray-100 dark:border-gray-700">
              {item.tags.slice(0, 3).map((tag, index) => (
                <span key={index} className="text-xs px-1.5 py-0.5 rounded bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                  #{tag}
                </span>
              ))}
              {item.tags.length > 3 && <span className="text-xs text-gray-400">+{item.tags.length - 3} more</span>}
            </div>
          )}
        </div>
      </div>

      {showEditModal && isAdmin() && (
        <MediaEditModal 
          item={item} 
          onClose={() => setShowEditModal(false)} 
          onSuccess={(updatedItem) => {
            if(onEditSuccess) onEditSuccess(updatedItem);
            setShowEditModal(false);
          }}
        />
      )}
    </>
  );
}

