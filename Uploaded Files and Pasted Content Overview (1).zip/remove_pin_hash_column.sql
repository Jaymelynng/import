-- SQL to remove the pin_hash column from gym_managers table

ALTER TABLE public.gym_managers
DROP COLUMN IF EXISTS pin_hash;

SELECT 
def_name AS column_name, 
data_type 
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'gym_managers';
-- This select statement is to verify the column has been removed.
-- You should see all columns except pin_hash.
