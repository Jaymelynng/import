/*
  # Initial Schema Setup

  1. New Tables
    - `gyms` - Stores gym information
    - `gym_links` - Stores links for each gym
    - `marketing_items` - Stores marketing content
    - `tasks` - Stores tasks related to marketing items

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create gyms table
CREATE TABLE IF NOT EXISTS gyms (
  id text PRIMARY KEY,
  name text NOT NULL,
  location text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create gym_links table
CREATE TABLE IF NOT EXISTS gym_links (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  gym_id text NOT NULL REFERENCES gyms (id),
  link_name text NOT NULL,
  link_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create marketing_items table
CREATE TABLE IF NOT EXISTS marketing_items (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  item_type text,
  title text NOT NULL,
  caption text,
  visuals_notes text,
  key_notes text,
  photo_examples text,
  post_format text,
  is_global boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  marketing_item_id uuid REFERENCES marketing_items (id),
  gym_id text REFERENCES gyms (id),
  title text NOT NULL,
  description text,
  due_date timestamptz,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE gyms ENABLE ROW LEVEL SECURITY;
ALTER TABLE gym_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketing_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Allow read access to all users" ON gyms FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to all users" ON gym_links FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to all users" ON marketing_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to all users" ON tasks FOR SELECT TO authenticated USING (true);