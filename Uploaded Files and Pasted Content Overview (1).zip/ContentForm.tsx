import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../../lib/supabase'; // Adjusted path
import { useAuth } from '../../../context/AuthContext'; // Adjusted path
import { Gym } from '../../../context/AuthContext'; // Assuming Gym type is exported

// Define a more specific type for the form data, aligning with marketing_items table
interface ContentFormData {
  title: string;
  item_type: string; // e.g., 'social_post', 'email_template', 'flyer', 'video_ad', 'blog_post'
  description: string; // Or 'caption' or 'notes'
  content_source: 'link' | 'upload';
  asset_url: string; // For external links or Supabase storage URL after upload
  thumbnail_url: string;
  // schedule_date: string; // Or 'publish_date'
  // status: string; // e.g., 'draft', 'pending_approval', 'approved', 'scheduled'
  gym_id: string | null; // UUID of the gym, or null for global content
  tags: string[]; // Array of tags
  // Add other relevant fields from your marketing_items table
  // For example: campaign_id, target_audience, call_to_action_url
}

const initialFormData: ContentFormData = {
  title: '',
  item_type: 'social_post', // Default type
  description: '',
  content_source: 'upload',
  asset_url: '',
  thumbnail_url: '',
  // schedule_date: new Date().toISOString().split('T')[0], // Default to today
  // status: 'draft',
  gym_id: null, // Default to global
  tags: [],
};

// Define available marketing item types
const ITEM_TYPES = [
  { value: 'social_post', label: 'Social Media Post' },
  { value: 'email_template', label: 'Email Template' },
  { value: 'flyer', label: 'Flyer/Poster' },
  { value: 'video_ad', label: 'Video Ad' },
  { value: 'blog_post', label: 'Blog Post' },
  { value: 'in_gym_material', label: 'In-Gym Material (Sticker, Banner etc.)' },
  { value: 'other', label: 'Other Digital Asset' },
];

export function ContentForm() {
  const { user, isAdmin } = useAuth();
  const [formData, setFormData] = useState<ContentFormData>(initialFormData);
  const [file, setFile] = useState<File | null>(null);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [gyms, setGyms] = useState<Gym[]>([]);
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const [currentTags, setCurrentTags] = useState('');

  useEffect(() => {
    if (!isAdmin()) return; // Only admins can use this form

    const fetchGyms = async () => {
      const { data, error } = await supabase.from('gyms').select('id, name').order('name');
      if (error) console.error('Error fetching gyms:', error);
      else setGyms(data || []);
    };
    fetchGyms();
  }, [isAdmin]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.name === 'file') setFile(e.target.files?.[0] || null);
    if (e.target.name === 'thumbnailFile') setThumbnailFile(e.target.files?.[0] || null);
  };
  
  const handleTagsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentTags(e.target.value);
  };

  const addTag = () => {
    if (currentTags.trim() !== '' && !formData.tags.includes(currentTags.trim())) {
      setFormData(prev => ({ ...prev, tags: [...prev.tags, currentTags.trim()] }));
    }
    setCurrentTags('');
  };

  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({ ...prev, tags: prev.tags.filter(tag => tag !== tagToRemove) }));
  };

  const uploadFile = async (fileToUpload: File, bucket: 'marketing_assets' | 'thumbnails'): Promise<string | null> => {
    if (!fileToUpload) return null;
    const fileExt = fileToUpload.name.split('.').pop();
    const fileName = `${user?.id || 'admin'}_${Date.now()}.${fileExt}`;
    const filePath = `${fileName}`;

    const { error: uploadError, data: uploadData } = await supabase.storage
      .from(bucket)
      .upload(filePath, fileToUpload);

    if (uploadError) {
      console.error(`Error uploading ${bucket} file:`, uploadError);
      setFormError(`Failed to upload ${bucket === 'thumbnails' ? 'thumbnail' : 'asset'}: ${uploadError.message}`);
      return null;
    }
    // Get public URL
    const { data: publicUrlData } = supabase.storage.from(bucket).getPublicUrl(filePath);
    return publicUrlData.publicUrl;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin() || !user) {
      setFormError('You do not have permission to perform this action.');
      return;
    }
    setLoading(true);
    setFormError(null);
    setFormSuccess(null);

    let assetUrl = formData.asset_url;
    let thumbnailUrl = formData.thumbnail_url;

    if (formData.content_source === 'upload') {
      if (file) {
        const uploadedAssetUrl = await uploadFile(file, 'marketing_assets');
        if (!uploadedAssetUrl) {
          setLoading(false);
          return; // Error already set by uploadFile
        }
        assetUrl = uploadedAssetUrl;
      } else {
        setFormError('Please select a file to upload for the main asset.');
        setLoading(false);
        return;
      }

      if (thumbnailFile) {
        const uploadedThumbnailUrl = await uploadFile(thumbnailFile, 'thumbnails');
        if (uploadedThumbnailUrl) thumbnailUrl = uploadedThumbnailUrl;
        // If thumbnail upload fails, we can proceed without it or use assetUrl as fallback
      } else if (assetUrl && (file?.type.startsWith('image/') || file?.type.startsWith('video/'))) {
        // If no specific thumbnail, and main asset is image/video, consider using assetUrl as thumbnail
        thumbnailUrl = assetUrl; 
      }
    }

    const itemToInsert = {
      title: formData.title,
      item_type: formData.item_type,
      description: formData.description,
      asset_url: assetUrl,
      thumbnail_url: thumbnailUrl || assetUrl, // Fallback thumbnail to asset if it's an image/video
      // schedule_date: formData.schedule_date || null,
      // status: formData.status || 'draft',
      gym_id: formData.gym_id === '' ? null : formData.gym_id, // Ensure empty string becomes null for DB
      created_by: user.id, // Link to the admin user who created it
      tags: formData.tags,
      // Add any other fields from ContentFormData that map to your table
    };

    const { error: insertError, data: insertedData } = await supabase
      .from('marketing_items')
      .insert(itemToInsert)
      .select();

    if (insertError) {
      console.error('Error inserting marketing item:', insertError);
      setFormError(`Failed to add material: ${insertError.message}`);
    } else {
      setFormSuccess('Marketing material added successfully!');
      setFormData(initialFormData); // Reset form
      setFile(null);
      setThumbnailFile(null);
      setCurrentTags('');
      // Optionally, trigger a refresh of a list view if this form is part of a larger component
    }
    setLoading(false);
  };

  if (!isAdmin()) {
    return <div className="p-6 text-center text-red-500">Access Denied. Only admins can manage content.</div>;
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 shadow-lg">
      <h2 className="text-2xl font-semibold mb-6 text-gray-700 dark:text-gray-200">Add New Marketing Material</h2>
      
      {formError && <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">{formError}</div>}
      {formSuccess && <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-md">{formSuccess}</div>}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Title</label>
          <input
            type="text"
            name="title"
            id="title"
            value={formData.title}
            onChange={handleInputChange}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
            required
          />
        </div>

        <div>
          <label htmlFor="item_type" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Material Type</label>
          <select
            name="item_type"
            id="item_type"
            value={formData.item_type}
            onChange={handleInputChange}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
          >
            {ITEM_TYPES.map(type => (
              <option key={type.value} value={type.value}>{type.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Description / Notes</label>
          <textarea
            name="description"
            id="description"
            value={formData.description}
            onChange={handleInputChange}
            placeholder="Provide a brief description, caption, or any relevant notes for this material."
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
            rows={3}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Content Source</label>
          <div className="flex gap-4 mt-1">
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, content_source: 'upload' }))}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                formData.content_source === 'upload'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              Upload File
            </button>
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, content_source: 'link' }))}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                formData.content_source === 'link'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              External Link
            </button>
          </div>
        </div>

        {formData.content_source === 'link' ? (
          <div>
            <label htmlFor="asset_url" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Content URL</label>
            <input
              type="url"
              name="asset_url"
              id="asset_url"
              value={formData.asset_url}
              onChange={handleInputChange}
              placeholder="https://example.com/your-asset"
              className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
              required={formData.content_source === 'link'}
            />
          </div>
        ) : (
          <>
            <div>
              <label htmlFor="file" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Upload Main Asset</label>
              <input
                type="file"
                name="file"
                id="file"
                onChange={handleFileChange}
                className="w-full text-sm text-gray-500 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-800 file:text-indigo-700 dark:file:text-indigo-200 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-700"
                required={formData.content_source === 'upload'}
              />
            </div>
            <div>
              <label htmlFor="thumbnailFile" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Upload Thumbnail (Optional)</label>
              <input
                type="file"
                name="thumbnailFile"
                id="thumbnailFile"
                accept="image/*"
                onChange={handleFileChange}
                className="w-full text-sm text-gray-500 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-800 file:text-indigo-700 dark:file:text-indigo-200 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-700"
              />
            </div>
          </>
        )}
        
        <div>
          <label htmlFor="gym_id" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Assign to Gym (Optional)</label>
          <select
            name="gym_id"
            id="gym_id"
            value={formData.gym_id || ''} // Handle null value for select
            onChange={handleInputChange}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
          >
            <option value="">Global (All Gyms)</option>
            {gyms.map(gym => (
              <option key={gym.id} value={gym.id}>{gym.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="tags" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Tags</label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              id="tags"
              value={currentTags}
              onChange={handleTagsChange}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
              placeholder="Type a tag and press Enter"
              className="flex-grow px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
            />
            <button type="button" onClick={addTag} className="px-4 py-2 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 text-sm">Add Tag</button>
          </div>
          {formData.tags.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {formData.tags.map(tag => (
                <span key={tag} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                  {tag}
                  <button type="button" onClick={() => removeTag(tag)} className="ml-1.5 flex-shrink-0 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
                    <svg className="h-2 w-2" stroke="currentColor" fill="none" viewBox="0 0 8 8">
                      <path strokeLinecap="round" strokeWidth="1.5" d="M1 1l6 6m0-6L1 7" />
                    </svg>
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Add fields for schedule_date and status if needed */}

        <button
          type="submit"
          disabled={loading}
          className="w-full px-6 py-3 rounded-lg text-white font-semibold transition-colors duration-150 ${
            loading ? 'bg-indigo-400 curso
(Content truncated due to size limit. Use line ranges to read in chunks)