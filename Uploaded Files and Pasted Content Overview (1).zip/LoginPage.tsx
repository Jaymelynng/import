import React, { useState, useEffect } from 'react';
import { useAuth, Gym, GymUserDisplay } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom'; // Assuming react-router-dom is used for navigation

const LoginPage: React.FC = () => {
  const [gyms, setGyms] = useState<Gym[]>([]);
  const [selectedGym, setSelectedGym] = useState<string>('');
  const [usersInGym, setUsersInGym] = useState<GymUserDisplay[]>([]);
  const [selectedUserEmail, setSelectedUserEmail] = useState<string>(''); // Store email for login
  const [password, setPassword] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [pageError, setPageError] = useState<string | null>(null);

  const { fetchGyms, fetchUsersForGym, loginWithGymUserPassword, isAuthenticated, error: authError, clearError, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const loadGyms = async () => {
      setIsLoading(true);
      try {
        const fetchedGyms = await fetchGyms();
        setGyms(fetchedGyms);
      } catch (e: any) {
        setPageError(e.message || 'Failed to load gyms.');
      }
      setIsLoading(false);
    };
    loadGyms();
  }, [fetchGyms]);

  useEffect(() => {
    if (selectedGym) {
      const loadUsers = async () => {
        setIsLoading(true);
        setUsersInGym([]); // Clear previous users
        setSelectedUserEmail('');
        try {
          const fetchedUsers = await fetchUsersForGym(selectedGym);
          setUsersInGym(fetchedUsers);
        } catch (e: any) {
          setPageError(e.message || 'Failed to load users for the selected gym.');
        }
        setIsLoading(false);
      };
      loadUsers();
    }
  }, [selectedGym, fetchUsersForGym]);

  useEffect(() => {
    if (isAuthenticated && user) {
        // Navigate to dashboard or appropriate page after login
        // For now, let's assume a '/dashboard' route
        if (user.role === 'admin') {
            navigate('/admin-dashboard'); // Or a generic admin page
        } else if (user.role === 'manager' && user.gymId) {
            navigate(`/dashboard`); // Or a gym-specific dashboard /gym/${user.gymId}/dashboard
        } else {
            navigate('/'); // Fallback
        }
    }
  }, [isAuthenticated, navigate, user]);

  useEffect(() => {
    if (authError) {
        setPageError(authError);
    }
  }, [authError]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserEmail || !password) {
      setPageError('Please select your gym, name, and enter your password.');
      return;
    }
    setIsLoading(true);
    setPageError(null);
    clearError(); // Clear context error before new attempt
    try {
      await loginWithGymUserPassword(selectedUserEmail, password);
      // Navigation will be handled by the useEffect watching isAuthenticated
    } catch (err: any) {
      // AuthContext now sets its own error, which useEffect will pick up.
      // If loginWithGymUserPassword re-throws, it can be caught here too.
      // setPageError(err.message || 'Login failed. Please check your credentials.');
    }
    setIsLoading(false);
  };

  return (
    <div style={{ maxWidth: '400px', margin: '50px auto', padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h2>Manager Login</h2>
      <form onSubmit={handleLogin}>
        <div style={{ marginBottom: '15px' }}>
          <label htmlFor="gym-select">Select Gym:</label>
          <select 
            id="gym-select" 
            value={selectedGym} 
            onChange={(e) => setSelectedGym(e.target.value)} 
            disabled={isLoading}
            style={{ width: '100%', padding: '8px', marginTop: '5px' }}
          >
            <option value="">-- Select Gym --</option>
            {gyms.map((gym) => (
              <option key={gym.id} value={gym.id}>{gym.name}</option>
            ))}
          </select>
        </div>

        {selectedGym && (
          <div style={{ marginBottom: '15px' }}>
            <label htmlFor="user-select">Select Your Name:</label>
            <select 
              id="user-select" 
              value={selectedUserEmail} 
              onChange={(e) => setSelectedUserEmail(e.target.value)} 
              disabled={isLoading || usersInGym.length === 0}
              style={{ width: '100%', padding: '8px', marginTop: '5px' }}
            >
              <option value="">-- Select Name --</option>
              {usersInGym.map((gymUser) => (
                <option key={gymUser.userId} value={gymUser.email}>{gymUser.name}</option>
              ))}
            </select>
          </div>
        )}

        {selectedUserEmail && (
            <div style={{ marginBottom: '15px' }}>
                <label htmlFor="password">Password:</label>
                <input 
                type="password" 
                id="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                disabled={isLoading}
                style={{ width: '100%', padding: '8px', marginTop: '5px' }}
                />
            </div>
        )}
        
        {pageError && <p style={{ color: 'red' }}>{pageError}</p>}

        <button type="submit" disabled={isLoading || !selectedUserEmail || !password} style={{ padding: '10px 15px', cursor: 'pointer' }}>
          {isLoading ? 'Logging in...' : 'Login'}
        </button>
      </form>
      {/* TODO: Add a link or separate form for Admin login if needed */}
    </div>
  );
};

export default LoginPage;

