import React, { useEffect, useState } from 'react'
import { Bell } from "lucide-react";
import { supabase } from "../../../lib/supabase"; // Adjusted path
import { useAuth } from "../../context/AuthContext"; // Adjusted path
import { format, isBefore, parseISO } from "date-fns";
import { Link } from "react-router-dom";

interface NotificationItem {
  id: string;
  title: string;
  due_date: string;
  item_type: string; // e.g., task, email_approval_request, content_update
  related_item_id?: string;
  gym_id?: string;
  // Add other relevant fields based on what constitutes a notification
}

interface NotificationsListProps {
  userId?: string; // For user-specific notifications if any
  gymId?: string; // For gym-specific notifications (manager view)
}

export function NotificationsList({ userId, gymId }: NotificationsListProps) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNotifications = async () => {
      if (!user) {
        setLoading(false);
        return;
      }
      setLoading(true);
      const today = new Date();

      // Example: Fetch tasks due soon as notifications
      // This can be expanded to include other notification types like pending approvals, new content etc.
      let query = supabase
        .from("tasks")
        .select("id, title, due_date, status, gym_id")
        .lte("due_date", format(addDays(today, 7), "yyyy-MM-dd")) // Tasks due in the next 7 days
        .gte("due_date", format(today, "yyyy-MM-dd")) // Tasks not yet past due (or slightly past due if needed)
        .neq("status", "completed")
        .order("due_date", { ascending: true })
        .limit(10); // Limit number of notifications shown

      if (user.role === "manager" && user.gymId) {
        query = query.eq("gym_id", user.gymId);
      } else if (user.role !== "admin" && gymId) {
        // If a gymId is passed but user is not admin (e.g. specific component context)
        query = query.eq("gym_id", gymId);
      }
      // Admins see tasks for all gyms if no specific gymId is passed to the component

      const { data, error } = await query;

      if (error) {
        console.error("Error fetching task notifications:", error);
        setNotifications([]);
      } else {
        const formattedNotifications = (data || []).map((task: any) => ({
          id: task.id,
          title: task.title,
          due_date: task.due_date,
          item_type: "task_due_soon", // Custom type for this notification
          related_item_id: task.id,
          gym_id: task.gym_id,
        }));
        setNotifications(formattedNotifications);
      }
      setLoading(false);
    };

    fetchNotifications();
  }, [user, gymId]);

  const getNotificationLink = (notification: NotificationItem) => {
    if (notification.item_type === "task_due_soon" && notification.related_item_id) {
      return `/tasks/${notification.related_item_id}`;
    }
    // Add other link logic for different notification types
    return "#"; // Fallback
  };
  
  const getNotificationSubtitle = (notification: NotificationItem) => {
    if (notification.item_type === "task_due_soon") {
        const dueDate = parseISO(notification.due_date);
        const isPastDue = isBefore(dueDate, startOfDay(new Date()));
        return `Task due: ${format(dueDate, "MMM dd, yyyy")} ${isPastDue ? "(Past Due)" : ""}`;
    }
    return "Notification";
  }

  if (loading) {
    return (
      <div className="mb-10">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-gray-700 dark:text-gray-300">
          <Bell size={22} />
          Notifications
        </h2>
        <div className="space-y-3">
          {[...Array(3)].map((_, index) => (
            <div key={index} className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 animate-pulse h-16">
                <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-300 dark:bg-gray-600 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mb-10 bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-gray-700 dark:text-gray-300">
        <Bell size={22} />
        Notifications
      </h2>
      {notifications.length > 0 ? (
        <ul className="space-y-3">
          {notifications.map((notification) => (
            <Link key={notification.id} to={getNotificationLink(notification)} className="block">
              <li
                className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-lg hover:border-indigo-500 dark:hover:border-indigo-400 transition-all duration-200 ease-in-out bg-gray-50 dark:bg-gray-700/50"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium text-gray-800 dark:text-gray-100">{notification.title}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      {getNotificationSubtitle(notification)}
                    </p>
                  </div>
                  {/* Optionally add an icon or action here */}
                </div>
              </li>
            </Link>
          ))}
        </ul>
      ) : (
        <p className="text-center text-gray-500 dark:text-gray-400 py-4">No new notifications.</p>
      )}
    </div>
  );
}

// Helper function (can be moved to a utils file)
const { addDays, startOfDay } = require("date-fns");

