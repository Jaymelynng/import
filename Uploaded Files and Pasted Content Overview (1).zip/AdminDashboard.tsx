import React, { useState, useEffect } from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Users, ClipboardList, LayoutGrid, FileText, CalendarDays, Image, Settings, BarChart3 } from 'lucide-react';

interface AdminStats {
  totalGyms: number;
  totalManagers: number;
  pendingTasks: number;
  upcomingEvents: number;
}

export function AdminDashboard() {
  const { isAdmin, user } = useAuth();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    if (!isAdmin()) return;

    const fetchStats = async () => {
      setLoadingStats(true);
      try {
        const { count: totalGyms, error: gymsError } = await supabase
          .from('gyms')
          .select('*', { count: 'exact', head: true });
        if (gymsError) throw gymsError;

        // Assuming 'manager' role is stored in gym_users or a similar way to identify managers
        const { count: totalManagers, error: managersError } = await supabase
          .from('gym_users') 
          .select('user_id', { count: 'exact', head: true })
          .eq('role', 'manager'); // Adjust if role definition is different
        if (managersError) throw managersError;

        const { count: pendingTasks, error: tasksError } = await supabase
          .from('tasks')
          .select('*', { count: 'exact', head: true })
          .in('status', ['pending', 'in_progress']); // Example statuses
        if (tasksError) throw tasksError;

        const today = new Date().toISOString();
        const { count: upcomingEvents, error: eventsError } = await supabase
          .from('marketing_items') // Or your events table
          .select('*', { count: 'exact', head: true })
          .gte('schedule_date', today); // Assuming 'schedule_date' for events
        if (eventsError) throw eventsError;

        setStats({
          totalGyms: totalGyms || 0,
          totalManagers: totalManagers || 0,
          pendingTasks: pendingTasks || 0,
          upcomingEvents: upcomingEvents || 0,
        });
      } catch (error) {
        console.error('Error fetching admin stats:', error);
        // setStats(null); // Or set to default error state
      } finally {
        setLoadingStats(false);
      }
    };

    fetchStats();
  }, [isAdmin]);

  if (!isAdmin()) {
    return <Navigate to="/login" replace />;
  }

  const StatCard = ({ title, value, icon, isLoadingCard }: { title: string; value: string | number; icon: React.ReactNode, isLoadingCard: boolean }) => (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">{title}</p>
          {isLoadingCard ? (
            <div className="h-8 w-16 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mt-1"></div>
          ) : (
            <p className="text-3xl font-semibold text-gray-800 dark:text-gray-100 mt-1">{value}</p>
          )}
        </div>
        <div className="text-indigo-500 dark:text-indigo-400">
          {icon}
        </div>
      </div>
    </div>
  );

  const QuickLink = ({ to, title, icon, description }: { to: string; title: string; icon: React.ReactNode; description: string }) => (
    <Link 
      to={to} 
      className="block bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-xl hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all duration-300 ease-in-out group"
    >
      <div className="flex items-center text-indigo-600 dark:text-indigo-400 mb-3">
        {icon}
        <h3 className="ml-3 text-xl font-semibold text-gray-800 dark:text-gray-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-300">{title}</h3>
      </div>
      <p className="text-sm text-gray-600 dark:text-gray-300">{description}</p>
    </Link>
  );

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="mb-10">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-100">Admin Dashboard</h1>
        <p className="text-lg text-gray-600 dark:text-gray-400 mt-1">Welcome, {user?.email || 'Admin'}. Overview of the Gymnastics Marketing Hub.</p>
      </header>

      {/* Stats Grid */}
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-gray-700 dark:text-gray-200 mb-4">Hub At a Glance</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Total Gyms" value={stats?.totalGyms ?? '--'} icon={<LayoutGrid size={28} />} isLoadingCard={loadingStats} />
          <StatCard title="Managed Users" value={stats?.totalManagers ?? '--'} icon={<Users size={28} />} isLoadingCard={loadingStats} />
          <StatCard title="Pending Tasks" value={stats?.pendingTasks ?? '--'} icon={<ClipboardList size={28} />} isLoadingCard={loadingStats} />
          <StatCard title="Upcoming Content" value={stats?.upcomingEvents ?? '--'} icon={<CalendarDays size={28} />} isLoadingCard={loadingStats} />
        </div>
      </section>

      {/* Quick Links Section */}
      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-gray-700 dark:text-gray-200 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <QuickLink to="/admin/user-management" title="User Management" icon={<Users size={24} />} description="Add, edit, or remove manager accounts and assign gyms." />
          <QuickLink to="/admin/content-management" title="Content Creation" icon={<FileText size={24} />} description="Create and manage marketing materials, posts, and emails." />
          <QuickLink to="/admin/content-calendar" title="Master Calendar" icon={<CalendarDays size={24} />} description="View all scheduled marketing activities and tasks." />
          {/* Add more links as needed, e.g., to a settings page or reports */}
        </div>
      </section>
      
      {/* Placeholder for recent activity or other relevant admin sections */}
      {/* Example: Could be a list of recent content additions or pending approvals */}
      <section>
        <h2 className="text-2xl font-semibold text-gray-700 dark:text-gray-200 mb-4">Recent Activity (Placeholder)</h2>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
          <p className="text-gray-500 dark:text-gray-400">Recent activities and important notifications will be displayed here.</p>
          {/* This could be a feed of recent marketing_items, task updates, or email approval requests */}
        </div>
      </section>

    </div>
  );
}

