import React, { useState, useEffect, useCallback } from "react";
import { EmailList } from "./EmailList"; // Assuming this will be updated for Supabase
import { ReviewPanel } from "./ReviewPanel"; // Assuming this will be updated for Supabase
import { useAuth } from "../../context/AuthContext"; // Adjusted path
import { supabase } from "../../../lib/supabase"; // Adjusted path
import { MarketingItem } from "../../types/marketing"; // Assuming a general type for marketing items

interface GymEmailReviewProps {
  gymId?: string; // gym_id (UUID)
}

interface EmailForReview extends MarketingItem {
  // Add any email-specific fields if not in MarketingItem
  // e.g., subject, body_html, approval_status, review_notes
  approval_status?: "pending_review" | "approved" | "needs_edits";
  review_notes?: string;
}

export function GymEmailReview({ gymId }: GymEmailReviewProps) {
  const { user, isAdmin } = useAuth();
  const [emails, setEmails] = useState<EmailForReview[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<EmailForReview | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchEmailsForReview = useCallback(async () => {
    if (!gymId && !isAdmin()) {
      setEmails([]);
      setSelectedEmail(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);

    let query = supabase
      .from("marketing_items")
      .select("*, tasks(id, title, status)") // Example: join related tasks if needed
      .eq("item_type", "email") // Filter for emails
      // .order("created_at", { ascending: false }); // Or by schedule_date
      .order("schedule_date", { ascending: false, nullsFirst: false });


    if (!isAdmin() && gymId) {
      // Managers see emails for their gym or global emails (gym_id is null)
      query = query.or(`gym_id.eq.${gymId},gym_id.is.null`);
    } else if (isAdmin() && gymId) {
      // Admin viewing a specific gym
      query = query.eq("gym_id", gymId);
    }
    // If admin and no gymId, they see all emails

    const { data, error: supaError } = await query;

    if (supaError) {
      console.error("Error fetching emails for review:", supaError);
      setError(supaError.message);
      setEmails([]);
    } else {
      // @ts-ignore - Map to EmailForReview type
      setEmails((data as EmailForReview[]) || []);
    }
    setLoading(false);
  }, [gymId, isAdmin, user]);

  useEffect(() => {
    fetchEmailsForReview();
  }, [fetchEmailsForReview]);

  // Reset selected email when gymId changes or emails list reloads
  useEffect(() => {
    setSelectedEmail(null);
  }, [gymId, emails]);
  
  const handleSelectEmail = (emailId: string) => {
    const foundEmail = emails.find(e => e.id === emailId);
    setSelectedEmail(foundEmail || null);
  }

  const handleSubmitReview = async (
    emailId: string,
    status: "approved" | "needs_edits",
    notes: string
  ) => {
    if (!user) {
      alert("You must be logged in.");
      return;
    }

    // Check permissions: only managers of the assigned gym or admins can approve/edit
    const emailToUpdate = emails.find(e => e.id === emailId);
    if (!emailToUpdate) {
        alert("Email not found.");
        return;
    }

    if (!isAdmin() && emailToUpdate.gym_id !== user.gymId) {
        alert("You do not have permission to review this email.");
        return;
    }

    const { data, error: updateError } = await supabase
      .from("marketing_items")
      .update({
        approval_status: status,
        review_notes: notes,
        // Potentially update an `approved_by` or `reviewed_by` field with user.id
        // last_reviewed_at: new Date().toISOString(),
      })
      .eq("id", emailId)
      .select(); // Get the updated item back

    if (updateError) {
      console.error("Error submitting review:", updateError);
      alert(`Failed to submit review: ${updateError.message}`);
    } else {
      // Update local state to reflect the change immediately
      setEmails(prevEmails =>
        prevEmails.map(e => (e.id === emailId ? { ...e, approval_status: status, review_notes: notes } : e))
      );
      setSelectedEmail(null); // Close review panel or update its view
      alert("Review submitted successfully!");
    }
  };

  if (!gymId && !isAdmin()) {
    return (
      <div className="text-center py-8 text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        Please select a gym to view and review emails.
      </div>
    );
  }
  
  if (loading) {
    return <div className="text-center py-10 text-gray-500 dark:text-gray-400">Loading emails for review...</div>;
  }

  if (error) {
    return <div className="text-center py-10 text-red-500">Error loading emails: {error}</div>;
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      <div className="lg:w-1/3 xl:w-1/4 flex-shrink-0">
        <EmailList
          emails={emails}
          selectedEmailId={selectedEmail?.id || null}
          onSelectEmail={handleSelectEmail} // Pass email ID
          loading={loading}
        />
      </div>
      
      <div className="flex-grow">
        {selectedEmail ? (
          <ReviewPanel
            email={selectedEmail}
            onSubmitReview={handleSubmitReview}
            key={selectedEmail.id} // Ensure re-mount if selectedEmail changes
          />
        ) : (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 p-6 rounded-lg shadow h-full flex items-center justify-center">
            <p>Select an email from the list to review its content and submit feedback.</p>
          </div>
        )}
      </div>
    </div>
  );
}

