-- Supabase Schema for Gymnastics Marketing Hub
-- Version: 1.0
-- Date: 2025-05-06

-- Enable pgcrypto extension if not already enabled (for gen_random_uuid)
CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";

-- Create gyms table
CREATE TABLE IF NOT EXISTS public.gyms (
  id text PRIMARY KEY,
  name text NOT NULL,
  location text,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);
COMMENT ON TABLE public.gyms IS 'Stores information about each gym location.';

-- Create gym_links table
CREATE TABLE IF NOT EXISTS public.gym_links (
  id uuid DEFAULT extensions.gen_random_uuid() PRIMARY KEY,
  gym_id text NOT NULL REFERENCES public.gyms (id) ON DELETE CASCADE,
  link_name text NOT NULL,
  link_url text NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);
COMMENT ON TABLE public.gym_links IS 'Stores various links for each gym (e.g., website, social media).';

-- Create marketing_items table
CREATE TABLE IF NOT EXISTS public.marketing_items (
  id uuid DEFAULT extensions.gen_random_uuid() PRIMARY KEY,
  item_type text, -- e.g., 'social_post', 'email_campaign', 'in_gym_material'
  title text NOT NULL,
  caption text,
  visuals_notes text,
  key_notes text,
  photo_examples text, -- Could be URLs or descriptions
  post_format text,
  is_global boolean DEFAULT false,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);
COMMENT ON TABLE public.marketing_items IS 'Stores all marketing content items.';

-- Create tasks table
CREATE TABLE IF NOT EXISTS public.tasks (
  id uuid DEFAULT extensions.gen_random_uuid() PRIMARY KEY,
  marketing_item_id uuid REFERENCES public.marketing_items (id) ON DELETE SET NULL,
  gym_id text REFERENCES public.gyms (id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  due_date timestamptz,
  status text DEFAULT 'pending' NOT NULL, -- e.g., 'pending', 'in_progress', 'completed', 'needs_review'
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);
COMMENT ON TABLE public.tasks IS 'Tracks to-do items for managers related to marketing items, assigned to specific gyms.';

-- Create gym_managers table for PIN-based login
CREATE TABLE IF NOT EXISTS public.gym_managers (
    id uuid DEFAULT extensions.gen_random_uuid() PRIMARY KEY,
    user_id uuid NOT NULL UNIQUE REFERENCES auth.users (id) ON DELETE CASCADE,
    gym_id text NOT NULL REFERENCES public.gyms (id) ON DELETE CASCADE,
    pin_hash text NOT NULL, -- Store a securely hashed PIN, not plaintext
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);
COMMENT ON TABLE public.gym_managers IS 'Links Supabase authenticated users to gyms and stores their hashed PIN for gym-specific access.';

-- Create a helper function to update the updated_at column
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at columns
CREATE TRIGGER on_gyms_updated
  BEFORE UPDATE ON public.gyms
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

CREATE TRIGGER on_gym_links_updated
  BEFORE UPDATE ON public.gym_links
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

CREATE TRIGGER on_marketing_items_updated
  BEFORE UPDATE ON public.marketing_items
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

CREATE TRIGGER on_tasks_updated
  BEFORE UPDATE ON public.tasks
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

CREATE TRIGGER on_gym_managers_updated
  BEFORE UPDATE ON public.gym_managers
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

-- Row Level Security (RLS)

-- Enable RLS for all tables
ALTER TABLE public.gyms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gym_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.marketing_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gym_managers ENABLE ROW LEVEL SECURITY;

-- RLS Policies for gyms
CREATE POLICY "Allow public read access to gyms" ON public.gyms FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to gyms" ON public.gyms FOR ALL USING (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role') WITH CHECK (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role'); -- Assuming an 'admin_user_role' or service_role for admin operations

-- RLS Policies for gym_links
CREATE POLICY "Allow public read access to gym_links" ON public.gym_links FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to gym_links" ON public.gym_links FOR ALL USING (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role') WITH CHECK (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role');

-- RLS Policies for marketing_items
CREATE POLICY "Allow authenticated read access to marketing_items" ON public.marketing_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow admin full access to marketing_items" ON public.marketing_items FOR ALL USING (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role') WITH CHECK (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role');

-- RLS Policies for tasks
-- Managers can see tasks for their gym, Admins can see all.
CREATE POLICY "Allow managers to view tasks for their gym" ON public.tasks FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.gym_managers WHERE gym_managers.user_id = auth.uid() AND gym_managers.gym_id = tasks.gym_id)
);
CREATE POLICY "Allow managers to update tasks for their gym" ON public.tasks FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM public.gym_managers WHERE gym_managers.user_id = auth.uid() AND gym_managers.gym_id = tasks.gym_id)
) WITH CHECK (
  EXISTS (SELECT 1 FROM public.gym_managers WHERE gym_managers.user_id = auth.uid() AND gym_managers.gym_id = tasks.gym_id)
);
CREATE POLICY "Allow admin full access to tasks" ON public.tasks FOR ALL USING (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role') WITH CHECK (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role');

-- RLS Policies for gym_managers
CREATE POLICY "Allow admin full access to gym_managers" ON public.gym_managers FOR ALL USING (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role') WITH CHECK (auth.role() = 'service_role' OR (SELECT rolname FROM pg_roles WHERE oid = auth.role()::regrole) = 'admin_user_role');
CREATE POLICY "Allow manager to view their own gym_manager entry" ON public.gym_managers FOR SELECT TO authenticated USING (user_id = auth.uid());

-- Initial Data for Gyms Table

INSERT INTO public.gyms (id, name, location) VALUES
  ('capital-cedar-park', 'Capital Gymnastics Cedar Park', 'Cedar Park, TX'),
  ('capital-pflugerville', 'Capital Gymnastics Pflugerville', 'Pflugerville, TX'),
  ('capital-round-rock', 'Capital Gymnastics Round Rock', 'Round Rock, TX'),
  ('rowland-ballard-atascocita', 'Rowland Ballard - Atascocita', 'Atascocita, TX'),
  ('rowland-ballard-kingwood', 'Rowland Ballard - Kingwood', 'Kingwood, TX'),
  ('houston-gym-academy', 'Houston Gymnastics Academy', 'Houston, TX'),
  ('estrella-gymnastics', 'Estrella Gymnastics', 'Location TBD'),
  ('oasis-gymnastics', 'Oasis Gymnastics', 'Location TBD'),
  ('scottsdale-gymnastics', 'Scottsdale Gymnastics', 'Scottsdale, AZ'),
  ('tigar-gymnastics', 'Tigar Gymnastics', 'Location TBD')
ON CONFLICT (id) DO NOTHING;

-- Note on Admin User Role:
-- The RLS policies above for 'admin_user_role' assume you will create such a role in your Supabase project
-- or assign specific users to have elevated privileges that match this role concept.
-- Alternatively, you can manage admin access through Supabase's built-in roles or by checking specific user IDs.
-- For simplicity, 'service_role' (which your backend functions would use) has full access.

-- Note on PIN Hashing:
-- The application logic (frontend or backend functions) will be responsible for:
-- 1. Securely hashing a PIN when it's set or changed.
-- 2. Hashing a PIN entered by a user during login.
-- 3. Comparing the input hash with the stored pin_hash.
-- DO NOT store plaintext PINs in the database.

SELECT 'SQL script for Gymnastics Marketing Hub schema executed successfully.';

