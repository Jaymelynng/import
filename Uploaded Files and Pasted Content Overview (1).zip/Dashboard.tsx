import React, { useState, useEffect, useCallback } from 'react';
import { addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, format } from 'date-fns';
import { PageHeader } from '../components/Layout/PageHeader';
import { StatsGrid } from '../components/Dashboard/StatsGrid';
import { NotificationsList } from '../components/Dashboard/NotificationsList';
import { CalendarHeader } from '../components/Calendar/CalendarHeader';
import { CalendarGrid } from '../components/Calendar/CalendarGrid';
import { DayDetailsPanel } from '../components/Calendar/DayDetailsPanel';
import { CalendarDay, DayDetails, Task, Content } from '../types/calendar';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../../lib/supabase';

export function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [calendarDays, setCalendarDays] = useState<CalendarDay[]>([]);
  const [dayDetails, setDayDetails] = useState<DayDetails | null>(null);
  const [isLoadingCalendar, setIsLoadingCalendar] = useState(false);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);

  const handlePreviousMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const handleNextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));

  const fetchMarketingItemsForMonth = useCallback(async (month: Date, gymId?: string) => {
    const monthStart = startOfMonth(month);
    const monthEnd = endOfMonth(month);

    // Base query for marketing_items
    let query = supabase
      .from('marketing_items')
      .select('id, title, item_type, created_at, tasks(id, due_date, status, gym_id))') // Assuming tasks have a due_date or similar for calendar placement
      .gte('created_at', format(monthStart, 'yyyy-MM-dd')) // Or a specific date field for scheduling
      .lte('created_at', format(monthEnd, 'yyyy-MM-dd'));

    // TODO: Refine query to fetch items based on their scheduled date, not just created_at.
    // This might involve joining with a scheduling table or using a specific 'scheduled_date' field on marketing_items or tasks.

    const { data, error } = await query;
    if (error) {
      console.error('Error fetching marketing items:', error);
      return [];
    }
    return data || [];
  }, []);

  useEffect(() => {
    if (authLoading || !user) return;

    const generateAndSetCalendarDays = async () => {
      setIsLoadingCalendar(true);
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);
      const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
      
      // Fetch marketing items and tasks for the current month
      // This is a simplified fetch. Real implementation would need to map items to specific dates.
      const items = await fetchMarketingItemsForMonth(currentMonth, user.gymId);

      const generatedDays: CalendarDay[] = daysInMonth.map(date => {
        // Determine if there are tasks or content for this day based on fetched items
        // This logic needs to be more sophisticated based on actual data structure
        const hasTasks = items.some(item => 
          // @ts-ignore
          item.tasks.some(task => 
            // @ts-ignore
            isSameDay(new Date(task.due_date || item.created_at), date) && (user.role === 'admin' || task.gym_id === user.gymId || item.is_global)
          )
        );
        const hasContent = items.some(item => 
          // @ts-ignore
          isSameDay(new Date(item.created_at), date) && (user.role === 'admin' || item.is_global) // Simplified content check
        );

        return {
          date,
          hasTasks,
          hasContent,
          isToday: isSameDay(date, new Date())
        };
      });
      setCalendarDays(generatedDays);
      setIsLoadingCalendar(false);
    };

    generateAndSetCalendarDays();
  }, [currentMonth, user, authLoading, fetchMarketingItemsForMonth]);

  const fetchDayDetails = useCallback(async (date: Date, gymId?: string) => {
    setIsLoadingDetails(true);
    setDayDetails(null);
    const formattedDate = format(date, 'yyyy-MM-dd');

    // Fetch tasks for the selected date and gym
    let tasksQuery = supabase
      .from('tasks')
      .select('id, title, description, due_date, status, marketing_item_id')
      // Assuming due_date is just a date, or use a range for timestamp
      .eq('due_date', formattedDate); 
      // TODO: This needs to be a proper date range query if due_date includes time
      // .gte('due_date', format(startOfDay(date), 'yyyy-MM-dd HH:mm:ss'))
      // .lte('due_date', format(endOfDay(date), 'yyyy-MM-dd HH:mm:ss'));

    if (user?.role === 'manager' && gymId) {
      tasksQuery = tasksQuery.eq('gym_id', gymId);
    }
    const { data: tasksData, error: tasksError } = await tasksQuery;
    if (tasksError) {
      console.error('Error fetching tasks for day details:', tasksError);
    }

    // Fetch marketing content items for the selected date (simplified)
    // This should ideally link to marketing_items scheduled for this day.
    let contentQuery = supabase
      .from('marketing_items')
      .select('id, title, item_type, caption')
      .eq('created_at', formattedDate); // Placeholder: use a proper schedule date
      // TODO: Add gym filtering for content if applicable, or handle global content

    const { data: contentData, error: contentError } = await contentQuery;
    if (contentError) {
      console.error('Error fetching content for day details:', contentError);
    }

    const fetchedTasks: Task[] = (tasksData || []).map((t: any) => ({
      id: t.id,
      title: t.title,
      // checklist: [], // Placeholder, needs to be fetched if tasks have checklists
      description: t.description,
      due: t.due_date ? format(new Date(t.due_date), 'p') : 'N/A',
      status: t.status,
      marketing_item_id: t.marketing_item_id
    }));

    const fetchedContent: Content[] = (contentData || []).map((c: any) => ({
      id: c.id,
      title: c.title,
      type: c.item_type,
      // time: c.scheduled_time || '', // Placeholder
      // link: '' // Placeholder
      description: c.caption
    }));

    setDayDetails({ tasks: fetchedTasks, content: fetchedContent });
    setIsLoadingDetails(false);
  }, [user]);

  useEffect(() => {
    if (selectedDate && user) {
      fetchDayDetails(selectedDate, user.gymId);
    }
  }, [selectedDate, user, fetchDayDetails]);

  if (authLoading) {
    return <div>Loading user data...</div>;
  }

  if (!user) {
    // This should ideally not happen if ProtectedRoute is working, but as a fallback:
    return <div>User not found. Please login.</div>;
  }

  return (
    <div className="space-y-8">
      <PageHeader 
        title={user.role === 'admin' ? "Admin Dashboard" : `${user.gymName || 'Manager'} Dashboard`}
        description={user.role === 'admin' ? "Overview of all gyms and campaigns" : `Marketing overview for ${user.gymName || 'your gym'}`}
      />
      {/* StatsGrid and NotificationsList would also need to be data-driven and gym-specific for managers */}
      <StatsGrid gymId={user.role === 'manager' ? user.gymId : undefined} />
      <NotificationsList userId={user.id} gymId={user.role === 'manager' ? user.gymId : undefined} />
      
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1">
          <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 md:p-8 rounded-lg shadow-md">
            <CalendarHeader
              currentMonth={currentMonth}
              onPreviousMonth={handlePreviousMonth}
              onNextMonth={handleNextMonth}
            />
            {isLoadingCalendar ? (
              <div className="text-center py-10">Loading calendar...</div>
            ) : (
              <CalendarGrid
                days={calendarDays}
                onSelectDate={setSelectedDate}
                selectedDate={selectedDate}
              />
            )}
          </div>
        </div>
        {selectedDate && (
          <div className="w-full lg:w-1/3 xl:w-1/4">
            {isLoadingDetails ? (
                <div className="text-center py-10">Loading details...</div>
            ) : dayDetails ? (
                <DayDetailsPanel
                    selectedDate={selectedDate}
                    details={dayDetails}
                />
            ) : (
                <div className="text-center py-10 bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">No details for this day or failed to load.</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

