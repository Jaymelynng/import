import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Trash2, Calendar, Clock, Edit3, Filter, CheckCircle, Circle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../../lib/supabase'; // Adjusted path
import { AddTaskModal } from './AddTaskModal'; // Assuming this will be updated to use Supabase
import { TASK_CHANNEL_LABELS, TASK_STATUS_LABELS, TaskStatus, TaskChannel } from '../../utils/constants';
import { Task } from '../../types/tasks'; // Assuming Task type is defined
import { format, parseISO } from 'date-fns';

export function TaskList() {
  const { user, isAdmin } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<TaskChannel | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<TaskStatus | 'all'>('all');
  const [loading, setLoading] = useState(true);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const fetchTasks = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    let query = supabase.from('tasks').select('*, marketing_items(title, item_type)');

    if (user.role === 'manager' && user.gymId) {
      query = query.eq('gym_id', user.gymId);
    }
    // Admins see all tasks unless a filter is applied by them later

    if (selectedChannel !== 'all') {
      // Assuming 'channel' is a column in your 'tasks' table or related 'marketing_items' table
      // This might need adjustment based on your actual schema, e.g., filtering on marketing_items.item_type
      // For now, let's assume tasks have a 'channel' field directly or via marketing_items
      // query = query.eq('channel', selectedChannel); // Placeholder, adjust to your schema
    }

    if (selectedStatus !== 'all') {
      query = query.eq('status', selectedStatus);
    }

    query = query.order('due_date', { ascending: true });

    const { data, error } = await query;
    if (error) {
      console.error('Error fetching tasks:', error);
      setTasks([]);
    } else {
      // @ts-ignore - map data to Task type
      const formattedTasks = (data || []).map(t => ({
        id: t.id,
        title: t.title,
        description: t.description,
        dueDate: t.due_date,
        goLiveDate: t.go_live_date, // Assuming go_live_date field exists
        status: t.status as TaskStatus,
        channel: t.marketing_items?.item_type as TaskChannel || 'general', // Example mapping
        gymId: t.gym_id,
        marketing_item_id: t.marketing_item_id,
        marketing_item_title: t.marketing_items?.title
      }));
      setTasks(formattedTasks);
    }
    setLoading(false);
  }, [user, selectedChannel, selectedStatus]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const handleDeleteTask = async (taskId: string) => {
    if (!isAdmin()) return;
    if (window.confirm('Are you sure you want to delete this task?')) {
      const { error } = await supabase.from('tasks').delete().eq('id', taskId);
      if (error) {
        console.error('Error deleting task:', error);
        // Handle error display to user
      } else {
        setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
      }
    }
  };

  const handleUpdateTaskStatus = async (taskId: string, newStatus: TaskStatus) => {
    const { data, error } = await supabase
      .from('tasks')
      .update({ status: newStatus })
      .eq('id', taskId)
      .select(); // Select to get the updated row back

    if (error) {
      console.error('Error updating task status:', error);
    } else if (data) {
        // @ts-ignore
      setTasks(prevTasks => prevTasks.map(task => task.id === taskId ? { ...task, status: data[0].status } : task));
    }
  };
  
  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setShowAddModal(true); // Re-use AddTaskModal for editing
  };

  const handleModalClose = () => {
    setShowAddModal(false);
    setEditingTask(null);
    fetchTasks(); // Refresh tasks after add/edit
  }

  if (loading && !showAddModal) {
    return <div className="text-center py-10">Loading tasks...</div>;
  }

  return (
    <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-md">
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex gap-2 sm:gap-4">
          {isAdmin() && (
            <button
              onClick={() => {
                setEditingTask(null); // Ensure it's an add operation
                setShowAddModal(true);
              }}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 transition-colors duration-150"
            >
              <Plus size={18} />
              Add New Task
            </button>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 w-full sm:w-auto">
          <select
            value={selectedChannel} // This filter needs a 'channel' field on tasks or related marketing_items
            onChange={(e) => setSelectedChannel(e.target.value as TaskChannel | 'all')}
            className="px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-auto"
            title="Filter by channel (Feature in development)"
          >
            <option value="all">All Channels</option>
            {Object.entries(TASK_CHANNEL_LABELS).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value as TaskStatus | 'all')}
            className="px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-auto"
          >
            <option value="all">All Statuses</option>
            {Object.entries(TASK_STATUS_LABELS).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>
      </div>

      {tasks.length === 0 && !loading ? (
        <p className="text-center text-gray-500 dark:text-gray-400 py-8">No tasks found matching your criteria.</p>
      ) : (
        <div className="space-y-4">
          {tasks.map((task) => (
            <div
              key={task.id}
              className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600 hover:shadow-lg transition-all p-4"
            >
              <Link to={`/tasks/${task.id}`} className="flex-1 mb-3 sm:mb-0">
                <h3 className="font-semibold text-lg text-indigo-700 dark:text-indigo-400 mb-1 group-hover:underline">{task.title}</h3>
                {task.marketing_item_title && <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Related to: {task.marketing_item_title}</p>}
                <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2 mb-2">{task.description || 'No description available.'}</p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500 dark:text-gray-400">
                  <span className="flex items-center gap-1">
                    <Clock size={14} />
                    Due: {task.dueDate ? format(parseISO(task.dueDate), 'MMM dd, yyyy') : 'N/A'}
                  </span>
                  {task.goLiveDate && (
                    <span className="flex items-center gap-1">
                      <Calendar size={14} />
                      Goes Live: {format(parseISO(task.goLiveDate), 'MMM dd, yyyy')}
                    </span>
                  )}
                  <span className="font-medium px-2 py-0.5 rounded-full bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-200">
                    {TASK_CHANNEL_LABELS[task.channel] || task.channel}
                  </span>
                </div>
              </Link>
              <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                <select 
                    value={task.status} 
                    onChange={(e) => handleUpdateTaskStatus(task.id, e.target.value as TaskStatus)}
                    className={`text-xs font-medium px-2 py-1 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-1 dark:focus:ring-offset-gray-800
                        ${task.status === 'completed' ? 'bg-green-100 text-green-700 dark:bg-green-700 dark:text-green-100 focus:ring-green-500' : 
                          task.status === 'in_progress' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-600 dark:text-yellow-100 focus:ring-yellow-500' : 
                          'bg-gray-100 text-gray-700 dark:bg-gray-600 dark:text-gray-200 focus:ring-gray-500'}`}
                >
                    {Object.entries(TASK_STATUS_LABELS).map(([value, label]) => (
                        <option key={value} value={value}>{label}</option>
                    ))}
                </select>
                {isAdmin() && (
                  <>
                    <button
                        onClick={() => openEditModal(task)}
                        className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 p-1.5 rounded-md hover:bg-blue-100 dark:hover:bg-gray-600"
                        title="Edit task"
                    >
                        <Edit3 size={16} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.preventDefault(); // Prevent navigation if inside Link
                        handleDeleteTask(task.id);
                      }}
                      className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 p-1.5 rounded-md hover:bg-red-100 dark:hover:bg-gray-600"
                      title="Delete task"
                    >
                      <Trash2 size={16} />
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {showAddModal && (
        <AddTaskModal 
            onClose={handleModalClose} 
            gymIdForManager={user?.role === 'manager' ? user.gymId : undefined} 
            taskToEdit={editingTask}
        />
      )}
    </div>
  );
}

