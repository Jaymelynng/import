import React, { useState, useEffect, useCallback } from 'react';
import { X, Calendar as CalIcon, List, Grid, ChevronLeft, ChevronRight, PlusCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, startOfWeek, endOfWeek, eachWeekOfInterval, addDays, isSameMonth } from 'date-fns';
import { Link } from 'react-router-dom'; // For linking to task or item details

// Types
interface CalendarItem {
  id: string; // Can be marketing_item_id or task_id
  date: string; // ISO string date
  type: 'marketing_item' | 'task';
  title: string;
  description?: string;
  item_type?: string; // e.g., 'social_post', 'email', 'in_gym_material' for marketing_items
  status?: string; // e.g., 'pending', 'completed', 'overdue' for tasks
  gym_id?: string;
  color?: string; // For visual distinction
}

interface Day {
  date: Date;
  isCurrentMonth: boolean;
  isToday: boolean;
  items: CalendarItem[];
}

const CalendarView = () => {
  const { user, isAdmin } = useAuth();
  const [view, setView] = useState<'month' | 'week' | 'list'>('month');
  const [currentDate, setCurrentDate] = useState(new Date()); // For month/week navigation
  const [calendarItems, setCalendarItems] = useState<CalendarItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<CalendarItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [daysForMonthView, setDaysForMonthView] = useState<Day[]>([]);

  const fetchCalendarData = useCallback(async (startDate: Date, endDate: Date) => {
    if (!user) return [];
    setLoading(true);
    const fetchedItems: CalendarItem[] = [];

    // Fetch marketing items
    let miQuery = supabase
      .from('marketing_items')
      .select('id, title, item_type, created_at, gym_id, schedule_date') // Assuming a schedule_date field
      .gte('schedule_date', format(startDate, 'yyyy-MM-dd'))
      .lte('schedule_date', format(endDate, 'yyyy-MM-dd'));
    
    if (!isAdmin() && user.gymId) {
      // Managers see their gym's items or global items (gym_id is null)
      miQuery = miQuery.or(`gym_id.eq.${user.gymId},gym_id.is.null`);
    } // Admins see all

    const { data: miData, error: miError } = await miQuery;
    if (miError) console.error('Error fetching marketing items:', miError);
    if (miData) {
      miData.forEach(item => {
        fetchedItems.push({
          id: item.id,
          date: item.schedule_date || item.created_at, // Prefer schedule_date
          type: 'marketing_item',
          title: item.title,
          item_type: item.item_type,
          gym_id: item.gym_id,
          color: item.item_type === 'email' ? 'blue' : item.item_type === 'social_post' ? 'green' : 'purple'
        });
      });
    }

    // Fetch tasks
    let tasksQuery = supabase
      .from('tasks')
      .select('id, title, due_date, status, gym_id, description')
      .gte('due_date', format(startDate, 'yyyy-MM-dd'))
      .lte('due_date', format(endDate, 'yyyy-MM-dd'));

    if (!isAdmin() && user.gymId) {
      tasksQuery = tasksQuery.eq('gym_id', user.gymId);
    }

    const { data: tasksData, error: tasksError } = await tasksQuery;
    if (tasksError) console.error('Error fetching tasks:', tasksError);
    if (tasksData) {
      tasksData.forEach(task => {
        fetchedItems.push({
          id: task.id,
          date: task.due_date,
          type: 'task',
          title: task.title,
          description: task.description,
          status: task.status,
          gym_id: task.gym_id,
          color: task.status === 'completed' ? 'gray' : 'red'
        });
      });
    }
    setCalendarItems(fetchedItems);
    setLoading(false);
    return fetchedItems;
  }, [user, isAdmin]);

  useEffect(() => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    // Fetch data for a slightly wider range to cover days from prev/next month shown in month view
    const viewStartDate = startOfWeek(monthStart);
    const viewEndDate = endOfWeek(monthEnd);
    fetchCalendarData(viewStartDate, viewEndDate);
  }, [currentDate, fetchCalendarData]);

  useEffect(() => {
    // Generate days for the month view based on calendarItems and currentDate
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const displayStartDate = startOfWeek(monthStart);
    const displayEndDate = endOfWeek(monthEnd);

    const daysArray = eachDayOfInterval({ start: displayStartDate, end: displayEndDate });
    const newDaysForMonthView = daysArray.map(date => ({
      date,
      isCurrentMonth: isSameMonth(date, currentDate),
      isToday: isSameDay(date, new Date()),
      items: calendarItems.filter(item => isSameDay(parseISO(item.date), date))
    }));
    setDaysForMonthView(newDaysForMonthView);
  }, [calendarItems, currentDate]);


  const handleItemClick = (item: CalendarItem) => {
    setSelectedItem(item);
  };

  const handlePrev = () => {
    if (view === 'month') setCurrentDate(subMonths(currentDate, 1));
    if (view === 'week') setCurrentDate(subMonths(currentDate, 1)); // Or subWeeks
  };

  const handleNext = () => {
    if (view === 'month') setCurrentDate(addMonths(currentDate, 1));
    if (view === 'week') setCurrentDate(addMonths(currentDate, 1)); // Or addWeeks
  };
  
  const renderMonthView = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 sm:p-6">
      <div className="grid grid-cols-7 text-center font-semibold text-sm text-gray-600 dark:text-gray-400 border-b dark:border-gray-700 mb-2 pb-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => <div key={day}>{day}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-px">
        {daysForMonthView.map(({ date, isCurrentMonth, isToday, items }, index) => (
          <div 
            key={index} 
            className={`p-2 border dark:border-gray-700 min-h-[100px] sm:min-h-[120px] ${isCurrentMonth ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-700/50 text-gray-400 dark:text-gray-500'} ${isToday ? 'border-2 border-indigo-500 dark:border-indigo-400' : 'border-gray-200'}`}
          >
            <span className={`text-xs sm:text-sm font-medium ${isToday ? 'text-indigo-600 dark:text-indigo-300' : ''}`}>{format(date, 'd')}</span>
            <div className="mt-1 space-y-1 overflow-y-auto max-h-[80px] sm:max-h-[100px]">
              {items.map(item => (
                <div 
                  key={item.id} 
                  onClick={() => handleItemClick(item)}
                  className={`text-xs p-1 rounded cursor-pointer hover:opacity-80 truncate ${item.type === 'task' ? (item.status === 'completed' ? 'bg-green-100 text-green-700 dark:bg-green-700 dark:text-green-200' : 'bg-red-100 text-red-700 dark:bg-red-700 dark:text-red-200') : 'bg-blue-100 text-blue-700 dark:bg-blue-700 dark:text-blue-200'}`}
                  title={item.title}
                >
                  {item.title}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderListView = () => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 sm:p-6">
      <h2 className="text-xl font-semibold mb-4 text-gray-700 dark:text-gray-200">Events for {format(currentDate, 'MMMM yyyy')}</h2>
      {calendarItems.length === 0 && !loading && <p className="text-center text-gray-500 dark:text-gray-400 py-6">No items scheduled for this period.</p>}
      <div className="space-y-3">
        {calendarItems.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map(item => (
          <div 
            key={item.id}
            className="p-3 border dark:border-gray-700 rounded-lg cursor-pointer hover:shadow-md transition-all bg-gray-50 dark:bg-gray-700/50"
            onClick={() => handleItemClick(item)}
          >
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium text-gray-800 dark:text-gray-100">{item.title}</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {item.type === 'task' ? `Task - Status: ${item.status || 'N/A'}` : `Content - Type: ${item.item_type || 'N/A'}`}
                </p>
              </div>
              <span className="text-sm text-gray-600 dark:text-gray-300">{format(parseISO(item.date), 'MMM dd, yyyy')}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // Placeholder for Weekly View
  const renderWeekView = () => (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-6 text-gray-700 dark:text-gray-200">Weekly View for week of {format(startOfWeek(currentDate), 'MMM dd')}</h2>
          <p className="text-center py-12 text-gray-500 dark:text-gray-400">Weekly calendar view is under development.</p>
      </div>
  );

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
            <button onClick={handlePrev} className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300"><ChevronLeft size={24} /></button>
            <h1 className="text-2xl sm:text-3xl font-semibold text-gray-800 dark:text-gray-100">
                {format(currentDate, 'MMMM yyyy')}
            </h1>
            <button onClick={handleNext} className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300"><ChevronRight size={24} /></button>
        </div>
        <div className="flex gap-1 p-1 bg-gray-100 dark:bg-gray-700 rounded-lg self-start sm:self-center">
          {([ {label: 'Month', value: 'month', icon: Grid}, {label: 'Week', value: 'week', icon: CalIcon}, {label: 'List', value: 'list', icon: List} ]).map(v => {
            const Icon = v.icon;
            return (
              <button
                key={v.value}
                onClick={() => setView(v.value as 'month' | 'week' | 'list')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${view === v.value ? 'bg-white dark:bg-gray-900 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'}`}
                title={v.label}
              >
                <Icon size={18} />
              </button>
            );
          })}
        </div>
      </div>

      {loading && <div className="text-center py-10 text-gray-500 dark:text-gray-400">Loading calendar data...</div>}
      {!loading && view === 'month' && renderMonthView()}
      {!loading && view === 'week' && renderWeekView()} 
      {!loading && view === 'list' && renderListView()}

      {selectedItem && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedItem(null)}>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4 pb-3 border-b dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Item Details</h2>
              <button onClick={() => setSelectedItem(null)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
                <X size={20} />
              </button>
            </div>
            <div className="space-y-3">
              <h3 className="text-xl font-medium text-indigo-700 dark:text-indigo-400">{selectedItem.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                <strong>Date:</strong> {format(parseISO(selectedItem.date), 'MMMM dd, yyyy')}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                <strong>Type:</strong> {selectedItem.type === 'task' ? 'Task' : `Content (${selectedItem.item_type || 'N/A'})`}
              </p>
              {selectedItem.type === 'task' && selectedItem.status && (
                <p className="text-sm text-gray-600 dark:text-gray-300"><strong>Status:</strong> {selectedItem.status}</p>
              )}
              {selectedItem.description && <p className="text-sm text-gray-600 dark:text-gray-300 mt-2 whitespace-pre-wrap"><strong>Description:</strong> {selectedItem.description}</p>}
              <div className="pt-3 border-t dark:border-gray-700">
                {selectedItem.type === 'task' ? (
                    <Link to={`/tasks/${selectedItem.id}`} className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 font-medium">
                        View Task Details &rarr;
                    </Link>
                ) : (
                    // Link to marketing item detail page if it exists
                    <span className="text-gray-500 dark:text-gray-400 text-sm">More actions coming soon.</span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CalendarView;

